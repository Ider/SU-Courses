/////////////////////////////////////////////////////////////////////
// DemoForm.cpp - Uses sockets and blocks to send messages         //
// ver 2.4                                                         //
// Language:      Visual C++, 2008                                 //
// Platform:      Dell Precision 7500, Windows Vista, SP 1.0       //
// Application:   Utility for CSE687 Project #4                    //
// Author:        Jim Fawcett, Syracuse University, CST 2-187      //
//                (315) 443-3948, jfawcett@twcny.rr.com            //
/////////////////////////////////////////////////////////////////////

#include "DemoForm.h"

#include "..\sockets\sockets.h"
#include "..\threads\Threads.h"
#include "..\threads\locks.h"
#include "..\SocketCommunicator\Communicator.h"
#include "DemoForm.h"
#include <iostream>
#include <conio.h>
#include <vcclr.h>

using namespace SocketComm;

struct wrapper
{
  gcroot<DemoForm^> theForm;
};
struct transporter
{
  static wrapper theWrapper;
};
wrapper transporter::theWrapper;

/////////////////////////////////////////////////////////////////////
// Thread Proc classes for receiver

class MsgReceiver_Proc : public Thread_Processing
{
public:
  MsgReceiver_Proc(IMsgHandler* pMsgHandler) : _pMsgHandler(pMsgHandler) {}
  Thread_Processing* clone() const 
  { 
    return new MsgReceiver_Proc(_pMsgHandler); 
  }
  void run()
  {
    GLock<1> lock;
    std::string msg;
    lock.lock();
    BQueue<std::string>* pBQ = _pMsgHandler->getQueue();
    ICommunicator* pComm = _pMsgHandler->getCommunicator();
    EndPoint remoteEp = _pMsgHandler->getEndPoint();
    lock.unlock();
    DemoForm^ theForm = transporter::theWrapper.theForm;
    static int count = 0;

    ///////////////////////////////////////////////////////
    // insert your server processing here
    while(true)
    {
      msg = pBQ->deQ();
      sout << locker << "\n  receiver processing message #" << ++count << " "
           << msg.c_str() << unlocker;

      if(theForm->InvokeRequired)
        theForm->Invoke(theForm->myItemDelegate,gcnew array<System::Object^,1> { theForm->convert(msg) });

      if(msg == "quit")
        break;
    }
    // end of your code
    ///////////////////////////////////////////////////////
  }
private:
  IMsgHandler* _pMsgHandler;
};

class FileReceiver_Proc : public Thread_Processing
{
public:
  FileReceiver_Proc(IFileHandler* pFileHandler) : _pFileHandler(pFileHandler) {}
  Thread_Processing* clone() const { return new FileReceiver_Proc(_pFileHandler); }
  void run()
  {
    GLock<1> lock;
    std::string msg;
    lock.lock();
    BQueue<std::string>* pBQ = _pFileHandler->getQueue();
    ICommunicator* pComm = _pFileHandler->getCommunicator();
    EndPoint remoteEp = _pFileHandler->getEndPoint();
    lock.unlock();
    ///////////////////////////////////////////////////////
    // insert your server code here
    while(true)
    {
      sout << locker << "\n  receiver processing file: " << (msg = pBQ->deQ()).c_str() << unlocker;
      if(msg == "quit")
        break;
    }
    // end of your code
    ///////////////////////////////////////////////////////
  }
private:
  IFileHandler* _pFileHandler;
};

void DemoForm::setUpComm()
{
  try
  {
    // MsgReceiver_Proc is your receiver's server message handling
    // FileReceiver_Proc is your receiver's server file handling
    MsgHandler<MsgReceiver_Proc> rMsgHandler;
    rMsgHandler.setCommunicator(pComm);
    pComm->attachMsgHandler(&rMsgHandler);
    FileHandler<FileReceiver_Proc> rFileHandler;
    rFileHandler.setFileDestination(".\\debug\\received\\");
    rFileHandler.setCommunicator(pComm);
    pComm->attachFileHandler(&rFileHandler);
    pComm->listen();
  }
  catch(std::exception& ex)
  {
    sout << locker << "\n  " << ex.what() << "\n\n" << unlocker;
  }
}
[STAThreadAttribute]
int main()
{
//  HideConsole();

  sout << locker << "\n  Testing Socket Communicator with Form "
                 << "\n =======================================\n" << unlocker;

	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 
  
	// Create the main window and run it
  DemoForm^ theForm = gcnew SocketComm::DemoForm();
  transporter::theWrapper.theForm = theForm;
  Application::Run(theForm);
}


