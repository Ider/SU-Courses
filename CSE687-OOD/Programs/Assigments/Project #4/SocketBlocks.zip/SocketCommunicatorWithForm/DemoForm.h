#pragma once
/////////////////////////////////////////////////////////////////////
// DemoForm.h  -  Uses sockets and blocks to send messages         //
// ver 2.4                                                         //
// Language:      Visual C++, 2008                                 //
// Platform:      Dell Precision 7500, Windows Vista, SP 1.0       //
// Application:   Utility for CSE687 Project #4                    //
// Author:        Jim Fawcett, Syracuse University, CST 2-187      //
//                (315) 443-3948, jfawcett@twcny.rr.com            //
/////////////////////////////////////////////////////////////////////

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Text;

#include "../SocketCommunicator/ICommunicator.h"

namespace SocketComm {

	/// <summary>
	/// Summary for DemoForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class DemoForm : public System::Windows::Forms::Form
	{
	public:
		DemoForm(void)
		{
			InitializeComponent();
		}

	protected:
		~DemoForm()
		{
			if (components)
			{
				delete components;
			}
		}
  private: System::Windows::Forms::Button^  connectButton;
  protected: 

  protected: 
  private: System::Windows::Forms::TextBox^  textBox1;
  private: System::Windows::Forms::TextBox^  textBox2;
  private: System::Windows::Forms::Label^  label1;
  private: System::Windows::Forms::Button^  listenButton;

  private: System::Windows::Forms::TextBox^  textBox3;
  private: System::Windows::Forms::TextBox^  textBox4;
  private: System::Windows::Forms::Label^  label2;
  private: System::Windows::Forms::ListBox^  listBox1;
  private: System::Windows::Forms::ListBox^  listBox2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      this->connectButton = (gcnew System::Windows::Forms::Button());
      this->textBox1 = (gcnew System::Windows::Forms::TextBox());
      this->textBox2 = (gcnew System::Windows::Forms::TextBox());
      this->label1 = (gcnew System::Windows::Forms::Label());
      this->listenButton = (gcnew System::Windows::Forms::Button());
      this->textBox3 = (gcnew System::Windows::Forms::TextBox());
      this->textBox4 = (gcnew System::Windows::Forms::TextBox());
      this->label2 = (gcnew System::Windows::Forms::Label());
      this->listBox1 = (gcnew System::Windows::Forms::ListBox());
      this->listBox2 = (gcnew System::Windows::Forms::ListBox());
      this->SuspendLayout();
      // 
      // connectButton
      // 
      this->connectButton->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->connectButton->Location = System::Drawing::Point(399, 192);
      this->connectButton->Name = L"connectButton";
      this->connectButton->Size = System::Drawing::Size(75, 23);
      this->connectButton->TabIndex = 0;
      this->connectButton->Text = L"connect";
      this->connectButton->UseVisualStyleBackColor = true;
      this->connectButton->Click += gcnew System::EventHandler(this, &DemoForm::connectButton_Click);
      // 
      // textBox1
      // 
      this->textBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->textBox1->Location = System::Drawing::Point(108, 195);
      this->textBox1->Name = L"textBox1";
      this->textBox1->Size = System::Drawing::Size(164, 20);
      this->textBox1->TabIndex = 1;
      // 
      // textBox2
      // 
      this->textBox2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->textBox2->Location = System::Drawing::Point(295, 194);
      this->textBox2->Name = L"textBox2";
      this->textBox2->Size = System::Drawing::Size(76, 20);
      this->textBox2->TabIndex = 2;
      // 
      // label1
      // 
      this->label1->AutoSize = true;
      this->label1->Location = System::Drawing::Point(37, 200);
      this->label1->Name = L"label1";
      this->label1->Size = System::Drawing::Size(44, 13);
      this->label1->TabIndex = 3;
      this->label1->Text = L"Remote";
      // 
      // listenButton
      // 
      this->listenButton->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->listenButton->Location = System::Drawing::Point(399, 24);
      this->listenButton->Name = L"listenButton";
      this->listenButton->Size = System::Drawing::Size(75, 23);
      this->listenButton->TabIndex = 0;
      this->listenButton->Text = L"listen";
      this->listenButton->UseVisualStyleBackColor = true;
      this->listenButton->Click += gcnew System::EventHandler(this, &DemoForm::listenButton_Click);
      // 
      // textBox3
      // 
      this->textBox3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->textBox3->Location = System::Drawing::Point(108, 27);
      this->textBox3->Name = L"textBox3";
      this->textBox3->ReadOnly = true;
      this->textBox3->Size = System::Drawing::Size(164, 20);
      this->textBox3->TabIndex = 1;
      // 
      // textBox4
      // 
      this->textBox4->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->textBox4->Location = System::Drawing::Point(295, 26);
      this->textBox4->Name = L"textBox4";
      this->textBox4->Size = System::Drawing::Size(76, 20);
      this->textBox4->TabIndex = 2;
      // 
      // label2
      // 
      this->label2->AutoSize = true;
      this->label2->Location = System::Drawing::Point(37, 32);
      this->label2->Name = L"label2";
      this->label2->Size = System::Drawing::Size(33, 13);
      this->label2->TabIndex = 3;
      this->label2->Text = L"Local";
      // 
      // listBox1
      // 
      this->listBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->listBox1->FormattingEnabled = true;
      this->listBox1->Location = System::Drawing::Point(40, 63);
      this->listBox1->Name = L"listBox1";
      this->listBox1->Size = System::Drawing::Size(434, 95);
      this->listBox1->TabIndex = 4;
      // 
      // listBox2
      // 
      this->listBox2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
        | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->listBox2->FormattingEnabled = true;
      this->listBox2->Location = System::Drawing::Point(40, 238);
      this->listBox2->Name = L"listBox2";
      this->listBox2->Size = System::Drawing::Size(434, 108);
      this->listBox2->TabIndex = 4;
      // 
      // DemoForm
      // 
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->ClientSize = System::Drawing::Size(513, 404);
      this->Controls->Add(this->listBox2);
      this->Controls->Add(this->listBox1);
      this->Controls->Add(this->label2);
      this->Controls->Add(this->label1);
      this->Controls->Add(this->textBox4);
      this->Controls->Add(this->textBox2);
      this->Controls->Add(this->textBox3);
      this->Controls->Add(this->listenButton);
      this->Controls->Add(this->textBox1);
      this->Controls->Add(this->connectButton);
      this->Name = L"DemoForm";
      this->Text = L"DemoForm";
      this->Load += gcnew System::EventHandler(this, &DemoForm::DemoForm_Load);
      this->ResumeLayout(false);
      this->PerformLayout();

    }
#pragma endregion
  public:
    //----< delegates used to communicate from worker thread to form >---

    delegate Void itemDelegate(String^ str);  // defines type, itemDelegate
    itemDelegate^ myItemDelegate;             // instance, myItemDelegate

    //----< function called from delegate >------------------------------

    void remoteMessage(String^ msg)
    {
      listBox2->Items->Insert(0,msg);
    }
    //----< string conversion routines >---------------------------------

    std::string convert(String^ s)
    {
      std::string temp;
      for(int i=0; i<s->Length; ++i)
        temp += (char)s[i];
      return temp;
    }
    String^ convert(const std::string& s)
    {
      StringBuilder^ temp = gcnew StringBuilder();
      for(size_t i=0; i<s.size(); ++i)
        temp->Append((wchar_t)s[i]);
      return temp->ToString();
    }
  private: 
    //----< initialize communication infrastructure >--------------------

    System::Void DemoForm_Load(System::Object^  sender, System::EventArgs^  e) 
    {
      myItemDelegate += gcnew itemDelegate(this,&DemoForm::remoteMessage);
      textBox1->Text = localIP = "127.0.0.1";
      localPort = 8080;
      textBox2->Text = localPort.ToString();
      textBox3->Text = remoteIP = "127.0.0.1";
      remotePort = 8081;
      textBox4->Text = remotePort.ToString();
      EndPoint ep(convert(localIP),localPort);
      pComm = ICommunicator::Create(ep);
      msgCount = 1;
    }
    //----< start listener >---------------------------------------------

    System::Void listenButton_Click(System::Object^  sender, System::EventArgs^  e) 
    {
      sout << "\n  starting to listen";
      setUpComm();
    }
    //----< attempt to connect to remote Communicator >------------------

    System::Void connectButton_Click(System::Object^  sender, System::EventArgs^  e) 
    {
      int count = 0;

      while(!pComm->connect(convert(remoteIP),remotePort))
      {
        if(count++ > 50)
          return;
      }
      String^ msg = "important message #" + msgCount.ToString();
      ++msgCount;
      pComm->postMessage(convert(msg));
      listBox1->Items->Insert(0,msg);
      pComm->disconnect();
    }
    //----< set up message handlers >------------------------------------

    void setUpComm();

    String^ localIP;
    String^ remoteIP;
    int localPort, remotePort;
    ICommunicator* pComm;
    long msgCount;
  };
}
