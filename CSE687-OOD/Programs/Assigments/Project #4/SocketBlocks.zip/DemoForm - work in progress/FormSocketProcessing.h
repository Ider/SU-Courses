#ifndef FORMSOCKETPROCESSING_H
#define FORMSOCKETPROCESSING_H


using namespace System;
using namespace System::IO;
using namespace System::Text;
using namespace System::Windows::Forms;

public:
  void SetUpComm(String^ ip, int port)
  {
    MessageBox::Show("SetUP here");
  }

//#include "..\sockets\sockets.h"
//#include "..\threads\Threads.h"
//#include "..\threads\locks.h"
//#include "..\SocketCommunicator\Communicator.h"


#endif
