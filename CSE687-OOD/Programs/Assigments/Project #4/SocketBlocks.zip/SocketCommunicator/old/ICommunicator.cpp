/////////////////////////////////////////////////////////////////////
// ICommunicator.cpp - Interface for users of Communicator class   //
// ver 2.4                                                         //
// Language:      Visual C++, 2008                                 //
// Platform:      Dell Precision 7500, Windows Vista, SP 1.0       //
// Application:   Utility for CSE687 Project #4                    //
// Author:        Jim Fawcett, Syracuse University, CST 2-187      //
//                (315) 443-3948, jfawcett@twcny.rr.com            //
/////////////////////////////////////////////////////////////////////

#include "ICommunicator.h"
#include <sstream>

