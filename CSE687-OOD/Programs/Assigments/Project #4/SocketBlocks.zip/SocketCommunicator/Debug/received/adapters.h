#ifndef ADAPTERS_H
#define ADAPTERS_H
/////////////////////////////////////////////////////////////////////
// Adapters.h - Provides String and File Adapters for Communicator //
// ver 1.2                                                         //
// Language:      Visual C++, 2008                                 //
// Platform:      Dell Dimension 9200, Vista Ultimate              //
// Application:   Utility for CSE687 and CSE775 projects           //
// Author:        Jim Fawcett, Syracuse University, CST 4-187      //
//                (315) 443-3948, jfawcett@twcny.rr.com            //
/////////////////////////////////////////////////////////////////////
/*
   Module Operations:
   ==================
   Currently defines string adapter for Communicators.  Eventually
   will also provide File Adapter.

   Public Interface:
   =================
   Communicator<1> comm1;
   Communicator<2> comm2;
   comm2.listen(2049);
   comm1.connect("127.0.0.1",2049);
   StringAdapter<1> sa1(comm1);
   sa.sendString(ep,"Hello World");
   // meanwhile, in a thread proc nearby:
   StringAdapter<2> sa2(comm2);
   std::string str = sa2.getString();
   
   NOTE1: StringAdapter<int cid>::getString() HAS TO WAIT FOR QUEUE
          OF SENDER TO BE CREATED.  See test stub for details.

   NOTE2: StringAdapter must use the same BlkSize as Communicator.

   Required Files:
   ===============
   Adapter.h, Adapter.cpp

   Build Process:
   ==============
   cl /EHsc Adapter.cpp

   Maintenance History:
   ====================
   ver 1.2 : 17 Apr 08
   - fixed two bugs identified by Phil Pratt-Szeliga, e.g., added missing
     delete pBlock statements after posting blocks in sendString, and
     changed while condition from while(sz > 0) to while(true) at the
     end of getString.
   ver 1.1 : 04 Apr 08
   - fixed BlkSize bug (didn't match Communicator), expanded testing.
   - fixed bug parsing strings in sendString.
   - fixed bug in Main demo - allowed program to exit before thread 
     worker thread finished.
   ver 1.0 : 02 Apr 08
   - first release

 */

#include <string>
#include <fstream>
#include "..\SocketCommunicator\Communicator.h"
#include "..\threads\locks.h"

template <int cid>
class StringAdapter
{
public:
  StringAdapter(Communicator<cid>& comm) : comm_(comm) {}
  void sendString(EndPoint ep, const std::string& msg, size_t BlkSize=1024);
  std::string getString(EndPoint ep, size_t BlkSize=1024);
  bool stringAvail(EndPoint ep);
private:
  Communicator<cid>& comm_;
};

//----< send a string to remote communicator >-----------------------
//
// Expects to use a connected Communicator

template <int cid>
void StringAdapter<cid>::sendString(EndPoint ep, const std::string& msg, size_t BlkSize)
{
  size_t start = 0;
  size_t end = msg.size();

  // send start block

  Block* pBlock = comm_.startMsgBlock(ep, Block::message, BlkSize);
  size_t incr = pBlock->sizeOfBlock() - pBlock->sizeOfHeader() - 1;
  incr = min(incr,end-start);
  comm_.postBlock(pBlock);
  delete pBlock;
  std::string temp;

  // send data blocks

  while(start < end)
  {
    temp = msg.substr(start, incr);
    start += incr;
    pBlock = comm_.midMsgBlock(Block::message,(byte_*)temp.c_str(),temp.size());
    comm_.postBlock(pBlock);
    delete pBlock;
  }
  // send end block

  pBlock = comm_.endMsgBlock(Block::message);
  comm_.postBlock(pBlock);
  delete pBlock;
}
//----< is there anything waiting in queue? >------------------------

template <int cid>
bool StringAdapter<cid>::stringAvail(EndPoint ep)
{
  const int NUMTRIES = 100;
  Queues Qs = comm_.getQueues();
  GLock<cid> lock;
  int i;
  Queues::iterator iter, iterend;
  for(i=0; i<NUMTRIES; ++i)
  {
    lock.lock();
    iter = Qs.find(ep.toString());
    iterend = Qs.end();
    lock.unlock();
    if(iter != iterend)
      break;
    Sleep(100);
  }
  if(i == NUMTRIES)
    return false;

  lock.lock();
  BQueue<Block*>* pQ = (*iter).second;
  lock.unlock();
  return (pQ->size() > 0);
}

//----< get a string from remote communicator >----------------------

template <int cid>
std::string StringAdapter<cid>::getString(EndPoint ep, size_t BlkSize)
{
  const int NUMTRIES = 100;
  Queues Qs = comm_.getQueues();

  GLock<cid> lock;
  int i;
  Queues::iterator iter, iterend;
  for(i=0; i<NUMTRIES; ++i)
  {
    lock.lock();
    iter = Qs.find(ep.toString());
    iterend = Qs.end();
    lock.unlock();
    if(iter != iterend)
      break;
    Sleep(100);
  }
  if(i == NUMTRIES)
    throw std::exception("can't find EndPoint queue");

  lock.lock();
  BQueue<Block*>* pQ = (*iter).second;
  lock.unlock();
  Block* pBlock;
  std::string temp;

  while(true)
  {
    pBlock = pQ->deQ();
    if(pBlock->getState() == Block::end_message)
      break;
    temp += pBlock->toString();
  }
  return temp;
}

template <int cid>
class FileAdapter
{
public:
  FileAdapter(Communicator<cid>& comm) : comm_(comm) {}
  void sendFile(EndPoint ep, const std::string& filespec, const std::string& remotespec, size_t BlkSize=1024);
  std::string getFile(EndPoint ep, size_t BlkSize=1024);
  bool fileAvail(EndPoint ep);
private:
  Communicator<cid>& comm_;
};

//----< send a file to remote communicator >-------------------------
//
// Expects to use a connected Communicator

#pragma warning( disable: 4996 ) 
// warns about possible buffer overrun which can't happen with this design

template <int cid>
void FileAdapter<cid>::sendFile(EndPoint ep, const std::string& filespec, const std::string& remotespec, size_t BlkSize)
{
  std::filebuf readBuff;
  readBuff.open(filespec.c_str(), std::ios::in | std::ios::binary);
  if(!readBuff.is_open())
  {
    std::string msg = "\n  Can't open file \"";
    msg.append(filespec);
    msg.append("\" for reading\n");
    throw std::exception(msg.c_str());
  }

  // send start block

  Block* pBlock = comm_.startMsgBlock(ep, Block::file, BlkSize);
  size_t incr = pBlock->sizeOfBlock() - pBlock->sizeOfHeader() - 1;
  comm_.postBlock(pBlock);
  delete pBlock;

  // send file name

  pBlock = comm_.midMsgBlock(Block::file,(byte_*)remotespec.c_str(),remotespec.size()-1);
  comm_.postBlock(pBlock);
  delete pBlock;

  // send data blocks

  byte_* pBuffer = new byte_[BlkSize]; 
  while(true)
  {
    std::streamsize count = readBuff.sgetn(pBuffer,incr);
    *(pBuffer + count) = (byte_)"\0";
    if(count == 0)
      break;
    if(count < (std::streamsize)incr)
      --count;
    pBlock = comm_.midMsgBlock(Block::file,pBuffer,count-1);
    comm_.postBlock(pBlock);
    delete pBlock;
  }
  // send end block

  pBlock = comm_.endMsgBlock(Block::file);
  comm_.postBlock(pBlock);
  delete pBlock;
  delete [] pBuffer;
  readBuff.close();
}
//----< is there anything waiting in queue? >------------------------

template <int cid>
bool FileAdapter<cid>::fileAvail(EndPoint ep)
{
  const int NUMTRIES = 100;
  Queues Qs = comm_.getQueues();
  GLock<cid> lock;
  int i;
  Queues::iterator iter, iterend;
  for(i=0; i<NUMTRIES; ++i)
  {
    lock.lock();
    iter = Qs.find(ep.toString());
    iterend = Qs.end();
    lock.unlock();
    if(iter != iterend)
      break;
    Sleep(100);
  }
  if(i == NUMTRIES)
    return false;

  lock.lock();
  BQueue<Block*>* pQ = (*iter).second;
  lock.unlock();
  return (pQ->size() > 0);
}

//----< get a file from remote communicator >------------------------

template <int cid>
std::string FileAdapter<cid>::getFile(EndPoint ep, size_t BlkSize)
{
  const int NUMTRIES = 100;
  Queues Qs = comm_.getQueues();

  GLock<cid> lock;
  int i;
  Queues::iterator iter, iterend;
  for(i=0; i<NUMTRIES; ++i)
  {
    lock.lock();
    iter = Qs.find(ep.toString());
    iterend = Qs.end();
    lock.unlock();
    if(iter != iterend)
      break;
    Sleep(100);
  }
  if(i == NUMTRIES)
    throw std::exception("can't find EndPoint queue");

  lock.lock();
  BQueue<Block*>* pQ = (*iter).second;
  lock.unlock();
  Block* pBlock;
  byte_* pBuffer = new byte_[BlkSize];

  // read filespec

  pBlock = pQ->deQ();
  char buffer[255];
  int len = pBlock->sizeOfData();
  pBlock->copyDataFromBlock(buffer,len);
  buffer[len] = '\0';
  sout << locker << "\n  " << buffer << unlocker;

  std::filebuf writeBuff;
  writeBuff.open(buffer, std::ios::out | std::ios::binary);
  if(!writeBuff.is_open())
  {
    std::string msg = "\n\n  Can't open \"";
    msg.append(buffer);
    msg.append("\" for writing");
    throw std::exception(msg.c_str());
  }

  while(true)
  {
    pBlock = pQ->deQ();
    if(pBlock->getState() == Block::end_message)
      break;
    pBlock->copyDataFromBlock(pBuffer,pBlock->sizeOfData());
    writeBuff.sputn(pBuffer,pBlock->sizeOfData());
  }
  writeBuff.close();
  delete [] pBuffer;
  return std::string(buffer);
}

#endif 
