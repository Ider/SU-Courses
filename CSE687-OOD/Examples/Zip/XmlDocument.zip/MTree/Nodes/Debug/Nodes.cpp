///////////////////////////////////////////////////////////////////////////
// Nodes.cpp - demonstrate how to define a template node class           //
// ver 1.1                                                               //
// Language:    Visual C++, 2008                                         //
// Platform:    Dell Precision T7400, Vista Ultimate, SP1                //
// Application: CSE382 - Algorithms and Data Structures Demo, Fall 2008  //
// Author:      Jim Fawcett, Syracuse University, CST 4-187,             //
//              (315) 443-3948, jfawcett@twcny.rr.com                    //
///////////////////////////////////////////////////////////////////////////

#include <string>
#include "Nodes.h"

using namespace AbstractDataTypes;

void WalkTree(MNode<std::string>* pMNode)
{
  std::cout << "\n  " << pMNode->value();
  MNode<std::string>* pTemp;
  while(pTemp = pMNode->nextUnmarkedChild())
  {
    pTemp->isMarked() = true;
    WalkTree(pTemp);
  }
}

void main()
{
  std::cout << "\n  MNode<T> class demonstration";
  std::cout << "\n ==============================\n";

  MNode<std::string> root("root");
  MNode<std::string> child1("child1");
  MNode<std::string> child2("child2");
  MNode<std::string> grandchild11("grandchild11");
  MNode<std::string> grandchild21("grandchild21");
  MNode<std::string> grandchild22("grandchild22");
  MNode<std::string> greatgrandchild211("greatgrandchild211");
  MNode<std::string> child3("child3");

  child1.add(&grandchild11);
  grandchild21.add(&greatgrandchild211);
  child2.add(&grandchild21);
  child2.add(&grandchild22);
  root.add(&child1);
  root.add(&child2);
  root.add(&child3);

  WalkTree(&root);

  std::cout << "\n\n  removing first child";
  root.remove(&child1);
  std::cout << "\n  unmarking all nodes";
  root.isMarked() = false;
  child1.isMarked() = false;
  grandchild11.isMarked() = false;
  child2.isMarked() = false;
  grandchild21.isMarked() = false;
  grandchild22.isMarked() = false;
  greatgrandchild211.isMarked() = false;
  child3.isMarked() = false;

  WalkTree(&root);

  std::cout << "\n\n";
}
