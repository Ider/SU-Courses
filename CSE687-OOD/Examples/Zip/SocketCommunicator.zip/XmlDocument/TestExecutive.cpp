///////////////////////////////////////////////////////////////////////////
//  TestExecutive.cpp - Demonstrate Requirements are Met for Project #1  //
//  ver 1.2                                                              //
//                                                                       //
//  Language:      Visual C++ 2008, SP1                                  //
//  Platform:      Dell Precision T7400, Win 7 Pro                       //
//  Application:   Prototype for CSE687 Pr1, Sp10                        //
//  Author:        Jim Fawcett, CST 4-187, Syracuse University           //
//                 (315) 443-3948, jfawcett@twcny.rr.com                 //
///////////////////////////////////////////////////////////////////////////
/*
  Module Operations: 
  ==================
  This package provides a TestExecutive class that demonstrates each of the
  requirements in CSE687 - Object Oriented Design, Project #1.

  Build Process:
  ==============
  Required files
    - TextExecutive.cpp, XmlDocument(.h, .cpp), MTree.h, XmlNodes(.h, .cpp), 
      XmlElementParts(.h, .cpp), Tokenizer(.h, .cpp)
  Build commands (either one)
    - devenv XmlProcessing.sln
    - cl /EHsc TestExecutive.cpp XmlDocument.cpp XmlNodes.cpp MTree.cpp \
               XmlElementParts.cpp Tokenizer.cpp

  Maintenance History:
  ====================
  ver 1.2 : 18 Mar 10
  - Added invalid test strings in testR3(...) to track down bugs reported
    by Karthick Soundararaj.  Thanks Karthick.
  - The invalid strings are now commented out.
  ver 1.1 : 14 Mar 10
  - Changed XmlElement::ToString() and XmlElement::ToEndString() to keep
    self-closing tags self-closed.  Version 1.0 expended them to correct
    but not self-closed tags.
  - tested adding self closing tag.  Test passed.
  ver 1.0 : 27 Feb 10
  - first release

*/

#include <iostream>
#include <string>
#include "XmlDocument.h"

using namespace XmlProcessing;

class TestExecutive
{
public:
  void testR1();
  void testR2();
  void testR3(const std::string& fileName);
  void testR4();
  void testR5();
  void testR6();
  void testR7();
  void testR8();
  void testR9();
  void testR10();
  void testR11();
private:
  XmlDocument doc;
  std::string file;
};

//----< Req #1 test >------------------------------------------------------

void TestExecutive::testR1()
{
  std::cout << "\n  Requirement #1";
  std::cout << "\n ----------------";
  std::cout << "\n  Use compile.bat and run.bat found in the project directory.";
  std::cout << "\n  Examine the TestExecutive folder to find TestExecutive.Vcproj ==> C++";
  std::cout << std::endl;
}
//----< Req #2 test >------------------------------------------------------

void TestExecutive::testR2()
{
  std::cout << "\n  Requirement #2";
  std::cout << "\n ----------------";
  std::cout << "\n  Use Visual Studio Find (^F) to view all #include statements ";
  std::cout << "\n  to show that no C std::libraries have been included";
  std::cout << std::endl;
}
//----< Req #3 test >------------------------------------------------------

void TestExecutive::testR3(const std::string& fileName)
{
  std::cout << "\n  Requirement #3";
  std::cout << "\n ----------------\n";

  this->file = fileName;
  doc.verbose() = false;

  std::cout << "\n  Processing file " << fileName;
  std::cout << "\n  " << std::string(16 + strlen(fileName.c_str()),'-');
  try
  {
    doc.loadFile(fileName);  
    std::cout << doc.ToString() << "\n";
  }
  catch(std::exception ex)
  {
    std::cout << "\n  " << ex.what() << "\n\n";
  }
  std::cout << "\n  Processing XML String ";
  std::cout << "\n -----------------------";
  doc.clear();
  //std::string xmlStr = "<tag name='name\">text</tag>";
  // Tests for invalid XML - used to chase bugs
  //std::string xmlStr = "<? xml version=1.0 ?> 1234";
  //std::string xmlStr = "<? xml version=1.0 ?> </tag>";
  std::string xmlStr = "<root><child1>child1 body</child1><child2><grandchild21>gc body</grandchild21>some text</child2></root>";
  std::cout << "\n  Building XmlDocument from XML string:\n" << xmlStr << std::endl;
  doc.loadString(xmlStr);
  std::cout << "\n  Resulting document is:";
  std::cout << doc.ToString() << std::endl;

  std::cout << "\n  copying XmlDocument:";
  std::cout << "\n ----------------------";
  XmlDocument docCopy = doc;
  std::cout << docCopy.ToString() << std::endl;

  std::cout << "\n  assigning XmlDocument:";
  std::cout << "\n ------------------------";
  XmlDocument docAssign;
  docAssign = docCopy;
  std::cout << docAssign.ToString() << std::endl;

  std::cout << "\n  Writing document to foobar.xml";
  if(docAssign.ToFile("../foobar.xml"))
    std::cout << " succeeded";
  else
    std::cout << " failed";

  std::cout << std::endl;
}
//----< Req #4 test >------------------------------------------------------

void TestExecutive::testR4()
{
  std::cout << "\n  Requirement #4";
  std::cout << "\n ----------------\n";

  try
  {
    doc.loadFile(file);  
    std::cout << doc.ToString() << "\n";
  }
  catch(std::exception ex)
  {
    std::cout << "\n  " << ex.what() << "\n\n";
  }

  std::cout << "\n  Finding Elements by Attribute Value";
  std::cout << "\n -------------------------------------";
  std::cout << "\n  searching for attribute value \"Wintellect\"" << std::endl;;

  std::vector<IXmlNode*> foundElements = doc.findElements("Wintellect", XmlDocument::attribValue);
  for(size_t i=0; i<foundElements.size(); ++i)
  {
    std::cout << "\n" << foundElements[i]->ToString();
    std::cout << "\n" << foundElements[i]->ToEndString();
  }
  std::cout << std::endl;

  std::cout << "\n  Finding Elements by Attribute Name";
  std::cout << "\n -------------------------------------";
  std::cout << "\n  searching for attribute name \"course\"" << std::endl;;
  foundElements = doc.findElements("course", XmlDocument::attribName);
  for(size_t i=0; i<foundElements.size(); ++i)
  {
    std::cout << "\n" << foundElements[i]->ToString();
    std::cout << "\n" << foundElements[i]->ToEndString();
  }
  std::cout << std::endl;
}
//----< Req #5 test >------------------------------------------------------

void TestExecutive::testR5()
{
  std::cout << "\n  Requirement #5";
  std::cout << "\n ----------------\n";

  std::cout << "\n  Finding Elements by Tag Name";
  std::cout << "\n ------------------------------";
  std::cout << "\n  searching for tag \"title\"" << std::endl;

  std::vector<IXmlNode*> foundElements = doc.findElements("title", XmlDocument::tag);
  for(size_t i=0; i<foundElements.size(); ++i)
  {
    std::cout << "\n" << foundElements[i]->ToString();
    std::vector<IXmlNode*> children = foundElements[i]->getChildren();
    if(children.size() > 0)
      std::cout << "\n  " << children[0]->ToString();
    std::cout << "\n" << foundElements[i]->ToEndString();
  }
  std::cout << std::endl;
  std::cout << "\n  Finding Element by Tag Name";
  std::cout << "\n -----------------------------";
  std::cout << "\n  searching for tag \"title\"" << std::endl;

  IXmlNode* pNode = doc.findElement("title", XmlDocument::tag);
  if(pNode)
  {
    std::cout << "\n" << pNode->ToString();
    std::vector<IXmlNode*> children = pNode->getChildren();
    if(children.size() > 0)
      std::cout << "\n  " << children[0]->ToString();
    std::cout << "\n" << pNode->ToEndString();
  }
  std::cout << std::endl;
}
//----< Req #6 test >------------------------------------------------------

void TestExecutive::testR6()
{
  std::cout << "\n  Requirement #6";
  std::cout << "\n ----------------";
  XmlElementNode* pChild = new XmlElementNode("inserted");
  XmlTextNode* pText = new XmlTextNode("inserted text");
  pChild->addChild(pText);
  std::cout << "\n  adding \"inserted\" element as child of note\n";
  IXmlNode* pNode = doc.findElement("note", XmlDocument::tag);
  if(pNode)
  {
    doc.insertElement(pNode,pChild);
    std::cout << doc.ToString() << std::endl;
    // insertion succeeded so don't delete pChild
  }
  else
  {
    std::cout << "\n  insertElement failed";
    delete pChild;  // will also delete pText;
  }
  pNode = doc.findElement("note", XmlDocument::tag);
  std::cout << "\n  attempting to remove element " << pChild->ToString();
  if(pNode)
  {
    if(doc.deleteElement(pNode,pChild))
    {
      // if deleteElement succeeds it will delete pChild, so don't delete here
      std::cout << "\n  removed element\n";
      std::cout << doc.ToString() << std::endl;
    }
    else
      std::cout << "\n  failed to remove element\n";
  }
  else
    std::cout << "\n  deleteElement failed";

  std::cout << "\n  adding self-closing element \"<selfClosing attName=\'attValue\'/>\" to author";
  pChild = new XmlElementNode("selfClosing");
  pChild->addAttribute("attName", "attValue");
  pNode = doc.findElement("author",XmlDocument::tag);
  if(pNode)
  {
    doc.insertElement(pNode,pChild);
    //pNode->addChild(pChild);  // this works too
    // child node has joint the tree, so don't delete it
  }
  else
  {
    std::cout << "\n  insertion failed";
    delete pChild;
  }
  std::cout << "\n" << doc.ToString();
  std::cout << std::endl;
}
//----< Req #7 test >------------------------------------------------------

void TestExecutive::testR7()
{
  std::cout << "\n  Requirement #7";
  std::cout << "\n ----------------";

  IXmlNode* pNode = doc.findElement("xml", XmlDocument::tag);
  if(pNode)
  {
    std::vector<XmlNode::attributeItem> attribs = pNode->getAttributes();
    std::cout << "\n  attributes of element " << pNode->ToString();
    for(size_t i=0; i<attribs.size(); ++i)
    {
      std::cout << "\n    name = " << attribs[i].first;
      std::cout << ", value = " << attribs[i].second;
    }
  }
  pNode = doc.findElement("reference", XmlDocument::tag);
  if(pNode)
  {
    std::vector<XmlNode::attributeItem> attribs = pNode->getAttributes();
    std::cout << "\n  attributes of element " << pNode->ToString();
    for(size_t i=0; i<attribs.size(); ++i)
    {
      std::cout << "\n    name = " << attribs[i].first;
      std::cout << ", value = " << attribs[i].second;
    }
  }
  std::cout << std::endl;
}
//----< Req #8 test >------------------------------------------------------

void TestExecutive::testR8()
{
  std::cout << "\n  Requirement #8";
  std::cout << "\n ----------------";

  IXmlNode* pNode = doc.findElement("xml", XmlDocument::tag);
  if(pNode)
  {
    std::cout << "\n  attempting to remove encoding attribute ";
    std::cout << "from element\n    " << pNode->ToString();
    pNode->removeAttribute("encoding","utf-8");
    if(pNode)
    {
      std::cout << "\n  removed attribute encoding from element:";
      std::cout << "\n    " << pNode->ToString();
    }
    else
      std::cout << "\n  removal failed";
  }
  std::cout << std::endl;
}
//----< Req #9 test >------------------------------------------------------

void TestExecutive::testR9()
{
  std::cout << "\n  Requirement #9";
  std::cout << "\n ----------------";

  std::cout << "\n  This was demonstrated for Requirement #3!";
  std::cout << std::endl;
}
//----< Req #10 test >-----------------------------------------------------

void TestExecutive::testR10()
{
  std::cout << "\n  Requirement #10";
  std::cout << "\n -----------------";

  XmlElementNode* pTest = new XmlElementNode("testTag");
  XmlTextNode* pText = new XmlTextNode("test data");
  pTest->addChild(pText);

  IXmlNode* pNode = doc.findElement("reference", XmlDocument::tag);
  if(pNode)
  {
    pNode->addAttribute("id", "testId");
  }
  pNode = doc.findElement("reference", XmlDocument::tag);
  if(pNode)
    pNode->addChild(pTest);
  std::cout << doc.ToString();
  std::cout << std::endl;
}
//----< Req #11 test >-----------------------------------------------------

void TestExecutive::testR11()
{
  std::cout << "\n  Requirement #11";
  std::cout << "\n -----------------";

  std::cout << "\n  Look in the project folder to find a .sln file,";
  std::cout << " compile.bat, and run.bat.";
  std::cout << "\n  by now, you know that I've provided a zip file. :-)\n";
  std::cout << std::endl;
}
//----< test entrypoint >--------------------------------------------------

int main(int argc, char* argv[])
{
  std::cout << "\n  Demonstrating Requirements for Project #1 - Xml Document Model";
  std::cout << "\n ================================================================\n";

  TestExecutive te;
  try
  {
    te.testR1();
    te.testR2();
    te.testR3("../LectureNote.xml");
    te.testR4();
    te.testR5();
    te.testR6();
    te.testR7();
    te.testR8();
    te.testR9();
    te.testR10();
    te.testR11();
  }
  catch(std::exception& ex)
  {
    std::cout << "\n\n  handled exception: " << ex.what() << "\n\n";
  }
  std::cout << std::endl;
}