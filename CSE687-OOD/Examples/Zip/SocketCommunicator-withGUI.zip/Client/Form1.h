#pragma once
/////////////////////////////////////////////////////////////////////////////
// DemoClient.cpp - Demonstrate starting Repository Client for Project #4  //
//                                                                         //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2011               //
/////////////////////////////////////////////////////////////////////////////
/*
   Operations:
   ===========
   Using SocketCommunicator::Sender and SocketCommunicator::Receiver, this
   application attempts to connect to DemoServer.  If successful will send
   messages written to textbox.  Also listens for server replies, which it
   posts to its ListBox.

   Required Files:
   ---------------
   Form1.cpp, Comm.h, Client.cpp, Communicator.lib

   Build Process:
   --------------
   devenv DemoClient.sln /rebuild debug

   Maintenance History:
   ====================
   Ver 1.0 : 25 Apr 11
   - first release
*/

#include "..\Communicator\Comm.h"

namespace Client {
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
  using namespace System::Text;
  using namespace System::Threading;

	public ref class Form1 : public System::Windows::Forms::Form
	{
  private: System::Windows::Forms::TextBox^  textBox1;
  private: System::Windows::Forms::TextBox^  textBox2;
  private: System::Windows::Forms::TextBox^  textBox3;
  private: System::Windows::Forms::Button^  button1;
  private: System::Windows::Forms::Button^  button2;
  private: System::Windows::Forms::ListBox^  listBox1;

  private: SocketCommunicator::Receiver* pRcvr;
  private: SocketCommunicator::Sender* pSndr;
  private: bool connected;
  private: int port;

  private: System::Threading::Thread^ pRcvrThread;
  private: delegate Void itemDelegate(String^ str);
  private: itemDelegate^ msgItemDelegate;

  public:
		Form1(void)
		{
			InitializeComponent();

      textBox1->Text = "localhost";
      textBox2->Text = "8000";
      connected = false;
      port = 8010;
      pRcvr = new SocketCommunicator::Receiver(port);
      pRcvrThread = gcnew System::Threading::Thread(gcnew System::Threading::ThreadStart(this, &Form1::run)); 
      pRcvrThread->IsBackground = true;
      pRcvrThread->Start();
      msgItemDelegate += gcnew itemDelegate(this, &Form1::AddToListBox);
      button2->Enabled = false;
      this->Text = "DemoClient";
    }

	protected:
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      this->textBox1 = (gcnew System::Windows::Forms::TextBox());
      this->textBox2 = (gcnew System::Windows::Forms::TextBox());
      this->button1 = (gcnew System::Windows::Forms::Button());
      this->listBox1 = (gcnew System::Windows::Forms::ListBox());
      this->textBox3 = (gcnew System::Windows::Forms::TextBox());
      this->button2 = (gcnew System::Windows::Forms::Button());
      this->SuspendLayout();
      // 
      // textBox1
      // 
      this->textBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->textBox1->Location = System::Drawing::Point(39, 38);
      this->textBox1->Name = L"textBox1";
      this->textBox1->Size = System::Drawing::Size(155, 22);
      this->textBox1->TabIndex = 0;
      this->textBox1->Text = L"ip address";
      // 
      // textBox2
      // 
      this->textBox2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->textBox2->Location = System::Drawing::Point(222, 38);
      this->textBox2->Name = L"textBox2";
      this->textBox2->Size = System::Drawing::Size(68, 22);
      this->textBox2->TabIndex = 1;
      this->textBox2->Text = L"port";
      // 
      // button1
      // 
      this->button1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->button1->Location = System::Drawing::Point(336, 31);
      this->button1->Name = L"button1";
      this->button1->Size = System::Drawing::Size(91, 35);
      this->button1->TabIndex = 2;
      this->button1->Text = L"Connect";
      this->button1->UseVisualStyleBackColor = true;
      this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
      // 
      // listBox1
      // 
      this->listBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
        | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->listBox1->FormattingEnabled = true;
      this->listBox1->ItemHeight = 16;
      this->listBox1->Location = System::Drawing::Point(39, 130);
      this->listBox1->Name = L"listBox1";
      this->listBox1->Size = System::Drawing::Size(388, 244);
      this->listBox1->TabIndex = 3;
      // 
      // textBox3
      // 
      this->textBox3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->textBox3->Location = System::Drawing::Point(39, 85);
      this->textBox3->Name = L"textBox3";
      this->textBox3->Size = System::Drawing::Size(251, 22);
      this->textBox3->TabIndex = 4;
      this->textBox3->Text = L"message";
      // 
      // button2
      // 
      this->button2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
      this->button2->Location = System::Drawing::Point(336, 77);
      this->button2->Name = L"button2";
      this->button2->Size = System::Drawing::Size(91, 35);
      this->button2->TabIndex = 5;
      this->button2->Text = L"Send";
      this->button2->UseVisualStyleBackColor = true;
      this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
      // 
      // Form1
      // 
      this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->ClientSize = System::Drawing::Size(465, 436);
      this->Controls->Add(this->button2);
      this->Controls->Add(this->textBox3);
      this->Controls->Add(this->listBox1);
      this->Controls->Add(this->button1);
      this->Controls->Add(this->textBox2);
      this->Controls->Add(this->textBox1);
      this->Name = L"Form1";
      this->Text = L"Form1";
      this->Shown += gcnew System::EventHandler(this, &Form1::Form1_Shown);
      this->ResumeLayout(false);
      this->PerformLayout();

    }
#pragma endregion

  private:
    //----< once form is rendered, show MessageBox >-------------------

    System::Void Form1_Shown(System::Object^  sender, System::EventArgs^  e) 
    {
      System::Windows::Forms::MessageBox::Show("listening on port " + Int32(port).ToString());
    }
    //----< function to delegate to UI thread for showing msgs >-------

    void AddToListBox(String^ str)
    {
      listBox1->Items->Insert(0,str);
    }
    //----< thread processing function >-------------------------------

    void run()
    {
      try
      {
        SocketCommunicator::Message msg, vmsg;
        do
        {
          msg = pRcvr->GetMsg();
          String^ temp = convert(msg.ToString());
          if(this->InvokeRequired)
            this->Invoke(msgItemDelegate, gcnew array<System::Object^,1> { temp });
        } while(msg.body() != "file");
      }
      catch(std::exception& ex)
      {
        System::Windows::Forms::MessageBox::Show(convert(std::string(ex.what())));
      }
    }
    //----< helper string conversion functions >-----------------------

    std::string convert(System::String^ str)
    {
      std::string temp;
      for(int i=0; i<str->Length; ++i)
        temp += (char)str[i];
      return temp;
    }
    System::String^ convert(std::string& str)
    {
      StringBuilder^ temp = gcnew StringBuilder("");
      for(size_t i=0; i<str.size(); ++i)
        temp->Append((wchar_t)str[i]);
      return temp->ToString();
    }
    //----< attempt to connect >---------------------------------------

    System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
    {
      connected = false;
      std::string address = convert(textBox1->Text);
      int port = System::Convert::ToInt32(textBox2->Text);
      try
      {
        pSndr = new SocketCommunicator::Sender;
        SocketCommunicator::EndPoint ep(address,port);
        if(!pSndr->connect(ep))
        {
          System::Windows::Forms::MessageBox::Show("can't connect to EndPoint(" + textBox1->Text + ", " + textBox2->Text + ")");
          return;
        }
        connected = true;
        button2->Enabled = true;
      }
      catch(std::exception& /*ex*/)
      {
        System::Windows::Forms::MessageBox::Show("can't connect to EndPoint(" + textBox1->Text + ", " + textBox2->Text + ")");
      }
    }
    //----< attempt to send a message to DemoServer >------------------

    System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
    {
      if(!connected)
      {
        System::Windows::Forms::MessageBox::Show("not connected");
        return;
      }
      try
      {
        SocketCommunicator::Message msg(convert(textBox3->Text));
        pSndr->PostMsg(msg);
      }
      catch(std::exception& /*ex*/)
      {
        System::Windows::Forms::MessageBox::Show("lost connection");
        connected = false;
      }
    } 
  };
}

