#ifndef ICOMM_H
#define ICOMM_H

#include <string>

namespace SocketCommunicator
{
  struct IEndPoint
  {
    static IEndPoint CreateEndPoint(const std::string& address, long port);
    virtual std::string address()=0;
    virtual long port()=0;
    virtual std::string& ToString()=0;
  };

  struct IMessage
  {
    enum MsgType { text, file };
    static IMessage CreateMessage(const std::string& text="");
    virtual std::string& getEndPoint()=0;
    virtual MsgType& getMsgType()=0;
    virtual std::string& body()=0;
    virtual IEndPoint& returnAddress()=0;
    virtual std::string TypeToString()=0;
    virtual std::string ToString()=0;
    static Message FromString(const std::string& xml);
  }
}
#endif