/////////////////////////////////////////////////////////////////////////
// DemoServer.cpp - Demonstrate how to start Repository for Project #4 //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2011           //
/////////////////////////////////////////////////////////////////////////
/*
   Operations:
   ===========
   Using SocketCommunicator::Sender and SocketCommunicator::Receiver, this
   application listens for connections, recieves messages and echos them
   back to sender.

   Required Files:
   ---------------
   DemoServer.cpp, Communicator.lib

   Build Process:
   --------------
   devenv DemoServer.sln /rebuild debug

   Maintenance History:
   ====================
   Ver 1.0 : 25 Apr 11
   - first release
*/

#include "..\Communicator\Comm.h"
#include <sstream>

//----< attempt to convert literal string to integer >-----------------

int convert(const char* str)
{
  std::istringstream in(str);
  int i;
  in >> i;
  return i;
}
//----< start message echo server >------------------------------------

int main(int argc, char* argv[])
{
  std::cout << "\n  DemoServer accepts messages and echos them back to DemoClient";
  std::cout << "\n ===============================================================\n";

  std::cout << "\n  Note: These messages are not base64 encoded, so you can't send text";
  std::cout << "\n        files without adding that feature to this demo.  See the";
  std::cout << "\n        projects SenderApp and ReceiverApp for those details.\n";

  std::cout << "\n  This server simply echos all the messages it receives back to the sender\n";

  if(argc < 4)
  {
    std::cout << "\n  please enter client name, server listening port, and client listening port";
    std::cout << "\n  on the command line.";
    return 1;
  }
  std::cout << "\n  Arguments passed on DemoServer command line:";
  std::cout << "\n ----------------------------------------------";
  std::cout << "\n  Sending to client:\t\t" << argv[1];
  std::cout << "\n  server listening port:\t" << convert(argv[2]);
  std::cout << "\n  client listening port:\t" << convert(argv[3]);
  std::cout << std::endl;

  SocketCommunicator::Sender sndr;
  SocketCommunicator::Message msg;
  int tryCount = 0, MaxTries = 5;
  std::string ip = argv[1];
  int port = convert(argv[3]);
  while(++tryCount < MaxTries)
  {
    if(sndr.connect(SocketCommunicator::EndPoint(ip,port)))
      break;
    Sleep(100);
    std::cout << "\n  failed attempt to connect to endpoint(" << ip.c_str() << ", " << port << ")";
  }

  try
  {
    SocketCommunicator::Receiver rcvr(8000);
    SocketCommunicator::Message msg, vmsg;
    do
    {
      msg = rcvr.GetMsg();
      std::cout << "\n  Getting msg: " << msg.ToString();
      //msg.body() = "received your message";
      std::cout << "\n  echoing msg to DemoClient";
      sndr.PostMsg(msg);
    } while(msg.body() != "quit");

    std::cout << "\n\n  shutting down ReceiverApp Receiver";
  }
  catch(std::exception& ex)
  {
    std::cout << "\n\n  " << ex.what() << "\n\n";
    return 1;
  }
  return 0;
}
