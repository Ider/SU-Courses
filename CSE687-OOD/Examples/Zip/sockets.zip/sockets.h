#ifndef SOCKETS_H
#define SOCKETS_H
///////////////////////////////////////////////////////////////////////
//  sockets.h - brief demo, quite incomplete                         //
//              See SockUtils for fairly complete functionality      //
//              but not wrapped with classes.                        //
//                                                                   //
//  Jim Fawcett, CSE681 - Software Modeling & Analysis, Summer 2005  //
///////////////////////////////////////////////////////////////////////
//
//  This example demonstrates how to build basic socket classes.  The
//  results are illustrated by sending a message to itself over a socket
//  connection.  The listener is running on a child thread and only
//  serves one client.
//
//  What this demo does NOT do:
//    - listener does not handle clients, each on its own thread
//    - does no message framing

#include <winsock.h>
#include <string>

class initializer {

  public:
    initializer();
    ~initializer();
};

class socketBase {

  public:
    socketBase();
    virtual ~socketBase();
    bool listen(const int port);
    bool connect(const std::string &addr, int port);
     int send(const std::string &s);
     int recv(std::string &s);
    void sendAll(std::string &s);
    void recvAll(std::string &s);

  protected:
    static unsigned int _stdcall socketBase::startListener(void*);
    virtual bool listenHelper();
    initializer init;  // must come before SOCKET
    SOCKET _client;
    SOCKET _server;
    SOCKET _listener; 
    int _listenPort;
    int _connectPort;
    std::string _IPaddress;
};

//
///////////////////////////////////////////////////////////////////////
// No implementation of these classes

class sServer : public socketBase {

  public:
    sServer(const std::string &addr, int port);
    ~sServer();
    void listen();
};


class sClient : public socketBase {

  public:
    sClient(const std::string &addr, int port);
    ~sClient();
};

#endif
