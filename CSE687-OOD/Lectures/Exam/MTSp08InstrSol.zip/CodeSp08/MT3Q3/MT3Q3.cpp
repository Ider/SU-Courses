// MT3Q3

#include <iostream>

template <typename T>
class C
{
public:
  C(const T& t=0) : t_(t) { std::cout << "\n  C()"; }
  C(const C<T>& c) : t_(c.t_) { std::cout << "\n  C(c)"; }
  ~C() { std::cout << "\n  ~C()"; }
  C<T>& operator=(const C<T>& c)
  {
    std::cout << "\n  C::operator=(const C& c)";
    if(this == &c) return *this;
    t_ = c.t_;
    return *this;
  }
private:
  T t_;
};

template <typename T>
class B
{ 
public:
  B() : pC(new C<T>) { std::cout << "\n  B()"; }
  B(const B<T>& b) : pC(new C<T>(*(b.pC)))
  {
    std::cout << "\n  B(b)";
  }
  virtual ~B() { std::cout << "\n  ~B()"; delete pC; }
  B<T>& operator=(const B<T>& b)
  {
    std::cout << "\n  B::operator=(const B& b)";
    if(this == &b) return *this;
    delete pC;
    pC = new C<T>(*(b.pC));
    return *this;
  }
private: 
  C<T>* pC; 
};

template <typename T>
class D : public B<T>
{
public:
  D() { std::cout << "\n  D()"; }
  D(const D<T>& d) : B<T>(d)
  {
    std::cout << "\n  D(d)";
  }
  ~D() { std::cout << "\n  ~D();"; }
  D<T>& operator=(const D<T>& d)
  {
    std::cout << "\n  D::operator=(const D& d)";
    if(this == &d) return *this;
    B<T>::operator=(d);
    return *this;
  }
};

void main()
{
  D<int> d1, d2;
  D<int> d3 = d2 = d1;
  std::cout << "\n\n";
}