// MT2Q1.cpp

#include <iostream>
#include <vector>

template <typename T>
class Node
{
public:
  Node(const T& t=0) : t_(t), marked_(false) {};
  T& value() { return t_; }
  bool& marked() { return marked_; }
  Node<T>& add(Node<T>* pNode) { children_.push_back(pNode); return *this; }
  std::vector< Node<T>* >& children() { return children_; }
  // Compiler generated copy and assignment are shallow.
  // That makes sense for a Node class.
private:
  std::vector< Node<T>* > children_;
  T t_;
  bool marked_;
};

template <typename T>
void walkGraph(Node<T>* pNode)
{
  std::cout << "\n  " << pNode->value();
  pNode->marked() = true;
  for(size_t i=0; i<pNode->children().size(); ++i)
  {
    Node<T>* child = pNode->children()[i];
    if(!child->marked())
      walkGraph(child);
  }
}
void main()
{
  Node<int> n0(0);
  Node<int> n1(1);
  Node<int> n2(2);
  Node<int> n3(3);
  n0.add(&n2).add(&n1);
  n2.add(&n1).add(&n3);
  n3.add(&n0);

  walkGraph(&n0);
  std::cout << "\n\n";
}
