// MT3Q6.cpp

#include <iostream>
#include <string>

template <typename T>
T clone(T* pT)
{
  return T(*pT);  // copy returned by value
}

template <typename T>
T& cloneOnHeap(T* pT)
{
  return *new T(*pT); // copy placed on heap
}

void main()
{
  std::string* pS = new std::string("string to clone");
  std::cout << "\n  on stack: " << clone(pS).c_str();

  std::string& Sref = cloneOnHeap(pS);
  std::cout << "\n  on heap:  " << Sref.c_str() << "\n\n";
  delete &Sref;
}