// MT1Q6.cpp

#include <iostream>

template <typename T>
class Node
{
public:
  Node(Node<T>* pNode, const T& t=0) : next_(pNode), t_(t) {};
  T& value() { return t_; }
  Node<T>*& next() { return next_; }
  // Compiler generated copy and assignment are shallow.
  // That makes sense for a Node class.
private:
  Node<T>* next_;
  T t_;
};

template <typename T>
void walkList(Node<T>* pNode)
{
  std::cout << "\n  " << pNode->value();
  if(pNode->next() != 0)
    walkList(pNode->next());
}
void main()
{
  Node<int> n0(0,4);
  Node<int> n1(&n0,3);
  Node<int> n2(&n1,2);
  Node<int> n3(&n2,1);
  Node<int> n4(&n3,0);

  walkList(&n4);
  std::cout << "\n\n";

  // bypass node 2

  n3.next() = &n1;
  walkList(&n4);
  std::cout << "\n\n";
}
