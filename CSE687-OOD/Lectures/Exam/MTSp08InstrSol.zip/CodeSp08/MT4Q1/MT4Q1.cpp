// MT4Q1

#include <string>
#include <vector>
#include <iostream>

template <typename T>
class Invoker
{
public:
  void Register(T* pObj)
  {
    items.push_back(pObj);  // save pointer to user's object
  }
  void Invoke(const T& obj)
  {
    std::vector<T*>::const_iterator iter;
    for(iter=items.begin(); iter!=items.end(); ++iter)
      *(*iter) = obj;       // assign to user object
  }
private:
  std::vector<T*> items;    // pointers to user objects
};

template <typename T>
class GetInvoker
{
public:
  Invoker<T>& get() { return inv_; }
private:
  static Invoker<T> inv_;   // static so access in any scope
};

template <typename T>
Invoker<T> GetInvoker<T>::inv_;

template <typename T>
class scopeOne
{
public:
  scopeOne() { GetInvoker<T>().get().Register(&obj_); }
  void show() { std::cout << "\n  my object value is: " << obj_; }
private:
  T obj_;
};

template <typename T>
class scopeTwo
{
public:
  scopeTwo() { GetInvoker<T>().get().Register(&obj_); }
  void show() { std::cout << "\n  my object value is: " << obj_; }
private:
  T obj_;
};

void main()
{
  scopeOne<int> so;
  scopeTwo<int> st;
  GetInvoker<int>().get().Invoke(13);
  so.show();
  st.show();

  GetInvoker<int>().get().Invoke(53);
  so.show();
  st.show();

  std::cout << "\n\n";
}
