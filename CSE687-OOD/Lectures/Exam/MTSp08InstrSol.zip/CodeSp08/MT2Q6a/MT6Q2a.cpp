// MT2Q6a.cpp

#include <iostream>
#include <vector>
#include <list>
#include <set>

/////////////////////////////////////////////////////////
// This works, but is not as neat as MT2Q6 because
// the compiler needs help in deducing the return type

template <typename C, typename V>
V average(const C& con)
{
  if(con.size() == 0)
    return 0;
  C::const_iterator iter = con.begin();
  V sum = *iter;
  while(++iter!=con.end())
    sum += *iter;
  return sum/con.size();
}

//template <class V, template <class V> class C>
//typename V anotherAverage(const C<V>& con)
//{
//  if(con.size() == 0)
//    return 0;
//  C<V>::const_iterator iter = con.begin();
//  V sum = *iter;
//  while(++iter!=con.end())
//    sum += *iter;
//  return sum/con.size();
//}
//
//template <class V, template <class V> class C>
//class averageFunctor
//{
//public:
//  V operator()(const C<V>& con)
//  {
//    if(con.size() == 0)
//      return 0;
//    C::const_iterator iter = con.begin();
//    V sum = *iter;
//    while(++iter!=con.end())
//      sum += *iter;
//    return sum/con.size();
//  }
//};
//
void main()
{
  std::vector<double> vecd;
  vecd.push_back(1.5);
  vecd.push_back(2.0);
  vecd.push_back(2.5);
  std::cout << "\n  " << average<std::vector<double>, double>(vecd) << "\n";

  std::list<double> listd(vecd.begin(), vecd.end());
  std::cout << "\n  " << average<std::list<double>, double>(listd) << "\n";

  std::set<double> setd(vecd.begin(), vecd.end());
  std::cout << "\n  " << average<std::set<double>, double>(setd) << "\n\n";

  //vecd.clear();
  //vecd.push_back(1.5);
  //vecd.push_back(2.0);
  //vecd.push_back(2.5);
  //averageFunctor< double, std::vector<double> > anotherAverage;
  //std::cout << "\n  " << anotherAverage(vecd) << "\n";

  //std::list<double> listd(vecd.begin(), vecd.end());
  //std::cout << "\n  " << average<std::list<double>, double>(listd) << "\n";

  //std::set<double> setd(vecd.begin(), vecd.end());
  //std::cout << "\n  " << average<std::set<double>, double>(setd) << "\n\n";
}