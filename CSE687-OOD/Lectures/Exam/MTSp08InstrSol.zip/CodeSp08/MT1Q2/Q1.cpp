// MT1Q1.cpp  also solution for MT2Q3

#include <iostream>

class C
{
public:
  C() { std::cout << "\n  C()"; }
  C(const C& c) { std::cout << "\n  C(c)"; }
  ~C() { std::cout << "\n  ~C()"; }
  C& operator=(const C& c)
  {
    std::cout << "\n  C::operator=(const C& c)";
    if(this == &c) return *this;
    return *this; // nothing to assign
  }
};

class B
{ 
public:
  B() : pC(new C) { std::cout << "\n  B()"; }
  B(const B& b) : pC(new C(*(b.pC)))
  {
    std::cout << "\n  B(b)";
  }
  virtual ~B() { std::cout << "\n  ~B()"; delete pC; }
  B& operator=(const B& b)
  {
    std::cout << "\n  B::operator=(const B& b)";
    if(this == &b) return *this;
    delete pC;
    pC = new C(*(b.pC));
    return *this;
  }
private: 
  C* pC; 
};

class D : public B
{
public:
  D() { std::cout << "\n  D()"; }
  D(const D& d) : B(d)
  {
    std::cout << "\n  D(d)";
  }
  ~D() { std::cout << "\n  ~D();"; }
  D& operator=(const D& d)
  {
    std::cout << "\n  D::operator=(const D& d)";
    if(this == &d) return *this;
    B::operator=(d);
    return *this;
  }
};

void main()
{
  D d1, d2;
  D d3 = d2 = d1;
  std::cout << "\n\n";
}