// MT4Q5

#include <iostream>
#include <sstream>

template <typename T>
std::string ToString(const T& t)
{
  std::ostringstream convert;
  convert << t;
  return convert.str();
}

void main()
{
  double pi = 3.1415927;
  std::string converted = ToString(pi);
  std::cout << "\n  " << converted;

  converted = ToString((int)-17);
  std::cout << "\n  " << converted;

  converted = ToString("a literal string");
  std::cout << "\n  " << converted << "\n\n";
}