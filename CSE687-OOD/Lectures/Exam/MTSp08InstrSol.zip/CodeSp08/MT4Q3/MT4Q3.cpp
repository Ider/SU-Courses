// MT4Q3

#include <iostream>

template <typename T>
class C
{
public:
  C(const T& t=0) : t_(t) { std::cout << "\n  C()"; }
  C(const C<T>& c) : t_(c.t_) { std::cout << "\n  C(c)"; }
  ~C() { std::cout << "\n  ~C()"; }
  C<T>& operator=(const C<T>& c)
  {
    std::cout << "\n  C::operator=(const C& c)";
    if(this == &c) return *this;
    t_ = c.t_;
    return *this;
  }
private:
  T t_;
};

template <typename T>
class B
{ 
public:
  B() : c() { std::cout << "\n  B()"; }
  B(const B<T>& b) : c(b.c)
  {
    std::cout << "\n  B(b)";
  }
  virtual ~B() { std::cout << "\n  ~B()"; }
  B<T>& operator=(const B<T>& b)
  {
    std::cout << "\n  B::operator=(const B& b)";
    if(this == &b) return *this;
    c = b.c;
    return *this;
  }
private: 
  C<T> c; 
};

template <typename T>
class D : public B<T>
{
public:
  D() { std::cout << "\n  D()"; }
  D(const D<T>& d) : B<T>(d)
  {
    std::cout << "\n  D(d)";
  }
  ~D() { std::cout << "\n  ~D();"; }
  D<T>& operator=(const D<T>& d)
  {
    std::cout << "\n  D::operator=(const D& d)";
    if(this == &d) return *this;
    B<T>::operator=(d);
    return *this;
  }
};

void main()
{
  D<int> d1, d2;
  D<int> d3 = d2 = d1;
  std::cout << "\n\n";
}