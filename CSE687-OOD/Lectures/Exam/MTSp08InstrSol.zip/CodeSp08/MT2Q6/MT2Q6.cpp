// MT2Q6.cpp

#include <iostream>
#include <vector>
#include <list>
#include <set>

template <typename C>
typename C::value_type average(const C& con)
{
  if(con.size() == 0)
    return 0;
  C::const_iterator iter = con.begin();
  C::value_type sum = *iter;
  while(++iter!=con.end())
    sum += *iter;
  return sum/con.size();
}

void main()
{
  std::vector<double> vecd;
  vecd.push_back(1.5);
  vecd.push_back(2.0);
  vecd.push_back(2.5);
  std::cout << "\n  " << average(vecd) << "\n";

  std::list<double> listd(vecd.begin(), vecd.end());
  std::cout << "\n  " << average(listd) << "\n";

  std::set<double> setd(vecd.begin(), vecd.end());
  std::cout << "\n  " << average(setd) << "\n\n";
}