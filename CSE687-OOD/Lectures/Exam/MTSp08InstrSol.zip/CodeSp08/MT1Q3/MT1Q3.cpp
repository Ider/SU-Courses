// MT1Q3

#include <iostream>

template <typename T>
class sharing
{
public:
  T& value() { return t_; }
private:
  static T t_;
};

template <typename T>
T sharing<T>::t_ = 0;

void scopeOne()
{
  sharing<double> s;
  std::cout << "\n  shared value in scopeOne is: " << s.value();
  s.value() = -9.99999;
}

void scopeTwo()
{
  sharing<double> s;
  std::cout << "\n  shared value in scopeTwo is: " << s.value();
  s.value() = 0.00001;
}

void main()
{
  sharing<double> s;
  s.value() = 3.1415927;
  scopeOne();
  scopeTwo();
  std::cout << "\n  shared value in main is: " << s.value() << "\n\n";
}
