// MT3Q7

#include <string>
#include <vector>
#include <iostream>

typedef std::string Message;

class Invoker
{
public:
  void Register(Message* pObj)
  {
    items.push_back(pObj);
  }
  void Invoke(Message msg)
  {
    std::vector<Message*>::const_iterator iter;
    for(iter=items.begin(); iter!=items.end(); ++iter)
      *(*iter) = msg;
  }
private:
  std::vector<Message*> items;
};

class GetInvoker
{
public:
  Invoker& get() { return inv_; }
private:
  static Invoker inv_;
};

Invoker GetInvoker::inv_;

class scopeOne
{
public:
  scopeOne() { GetInvoker().get().Register(&message_); }
  void show() { std::cout << "\n  my message is: " << message_; }
private:
  Message message_;
};

class scopeTwo
{
public:
  scopeTwo() { GetInvoker().get().Register(&message_); }
  void show() { std::cout << "\n  my message is: " << message_; }
private:
  Message message_;
};

void main()
{
  scopeOne so;
  scopeTwo st;
  GetInvoker().get().Invoke("first message");
  so.show();
  st.show();

  GetInvoker().get().Invoke("second message");
  so.show();
  st.show();

  std::cout << "\n\n";
}
