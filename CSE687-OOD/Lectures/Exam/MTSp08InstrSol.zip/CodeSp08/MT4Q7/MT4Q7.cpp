// MT4Q7

#include <iostream>

class B
{
public:
  B() { std::cout << "\n  B()"; }
  virtual ~B() { std::cout << "\n  destroying B"; }
  void f1() { std::cout << "\n  f1()"; }
  virtual B* f2() { std::cout << "\n  B::f2()"; return this; }
private:
};

class D: public B
{
public:
  D() { std::cout << "\n  D()"; }
  B* f2() { std::cout << "\n  D::f2()"; return this; }
  ~D() { std::cout << "\n  ~D()"; }
  void f3() { std::cout << "\n  D::f3()"; }
private:
};

void main()
{
  B* pB = new D;
  pB->f2();

  D* pD = dynamic_cast<D*>(pB);
  if(pD)
    pD->f3();

  std::cout << "\n\n";
}