// Append.cpp

//template <typename C>
//struct IFunctor
//{
//  virtual bool operator()(C::iterator iter);
//};

void main()
{
}