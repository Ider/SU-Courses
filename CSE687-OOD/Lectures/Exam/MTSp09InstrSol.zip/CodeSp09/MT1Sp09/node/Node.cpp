#include "Node.h"
#include <string>
#include <iostream>

typedef std::string stdStr;

class functor : public IFunc<stdStr>
{
  void operator()(node<stdStr>* pNode, int level)
  {
    std::cout << "\n";
    for(int i=0; i<level; ++i)
      std::cout << "  ";
    std::cout << pNode->value();
  }
};

void main()
{
  node<stdStr> n1(1,"one");
  node<stdStr> n2(2,"two");
  node<stdStr> n3(3,"three");
  node<stdStr> n4(4,"four");
  node<stdStr> n5(5,"five");
  node<stdStr> n6(6,"six");
  node<stdStr> n7(7,"seven");
  n1.add(&n2);
  n1.add(&n3);
  n3.add(&n4);
  n1.add(&n5);
  n4.add(&n6);
  n6.add(&n7);
  functor f;
  DFS(&n1,f);
  std::cout << "\n\n";
}
