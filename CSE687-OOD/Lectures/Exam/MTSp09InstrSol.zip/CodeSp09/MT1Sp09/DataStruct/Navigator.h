#ifndef NAVIGATOR_H
#define NAVIGATOR_H
/////////////////////////////////////////////////////////////////
// Navigator.h - Reusable directory navigator                  //
//                                                             //
// Jim Fawcett, CSE687 - Object Oriented Design, Midterm Sp09  //
/////////////////////////////////////////////////////////////////

#include <string>
#include "FileSystem.h"

struct IDirNav  // similar in concept to base command class
{
  virtual void file(const std::string& filename) = 0;
  virtual void directory(const std::string& dirname) = 0;
  virtual ~IDirNav() {};
};

class Navigator  // similar in concept to command pattern invoker
{
public:
  Navigator(const std::string& pattern) : pattern_(pattern) {};
  void go(const std::string& path);
  void reg(IDirNav* pIdn) { pIdn_ = pIdn; }
private:
  IDirNav* pIdn_;
  WinTools_Extracts::FileHandler fh;  // analyzes directory info
  std::string pattern_;               // search pattern
};

#endif
