// StringReverse.cpp

#include <string>

std::string Reverse(std::string str)
{
  std::string::iterator iter1, iter2;
  for(iter1=str.begin(), iter2=--str.end(); iter1 < iter2; ++iter1, --iter2)
  {
    char temp = *iter1;
    *iter1 = *iter2;
    *iter2 = temp;
  }
  return str;
}
#include <iostream>
void main()
{
  std::string test = "CSE687 - Object Oriented Design";
  std::cout << "\n  " << test.c_str();
  std::cout << "\n  " << Reverse(test).c_str() << "\n\n";
}