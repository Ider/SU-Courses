// cloner.cpp

#include <iostream>

template <typename T>
class clonerBase
{
public:
  static clonerBase<T>* Create() { return new T; }
  virtual void op() { std::cout << "\n  Hi from " << typeid(*this).name(); }
  virtual ~clonerBase<T>() {};
};

class clonerD1 : public clonerBase<clonerD1>
{
public:
  void op() { std::cout << "\n  Hi from clonerD1"; }
};

class clonerD2 : public clonerBase<clonerD2>
{
public:
  void op() { std::cout << "\n  Hi from clonerD2"; }
};

class clonerD3 : public clonerBase<clonerD3> {};

void main()
{
  clonerBase<clonerD1>* pD1 = clonerBase<clonerD1>::Create();
  pD1->op();
  clonerBase<clonerD2>* pD2 = clonerBase<clonerD2>::Create();
  pD2->op();
  clonerBase<clonerD3>* pD3 = clonerBase<clonerD3>::Create();
  pD3->op();
  std::cout << "\n\n";
}
