/////////////////////////////////////////////////////////////////
// container.cpp - templates and containers                    //
//                                                             //
// Jim Fawcett, CSE687 - Object Oriented Design, Midterm Sp09  //
/////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <string>

template <typename C>
std::string show(const C& con)
{
  std::ostringstream out;
  C::const_iterator iter;
  for(iter=con.begin(); iter!=con.end(); ++iter)
    out << "\n  " << *iter;
  out << "\n\n";
  return out.str();
}

void main()
{
  std::string myFriends[] = {
    "Terminator",
    "Jack The Ripper",
    "Lucretia Borgia",
    "Attila the Hun",
    "Genghis Khan"
  };

  std::list<std::string> friends(myFriends, myFriends+5);
  
  try 
  {
    std::ostringstream outss;
    outss << show(friends) << '\0';
    std::istringstream inss(outss.str());
    std::streambuf* pBuf = inss.rdbuf();
    std::cout << pBuf;
    std::cout << outss.str().c_str();
    if(!outss.good())
      throw std::exception("bad ostringstream state");
    outss.seekp(std::ios::beg);
    std::ofstream outfs("outfile.txt",std::ios::out | std::ios::trunc);
    if(outfs.good())
      std::cout << "\n  ofstream state good";
    outfs << outss.str().c_str();
    outfs.flush();
    if(!outfs.good())
      throw std::exception("bad ofstream state");
    outfs.close();
    outss.seekp(std::ios::beg);
    std::cout << outss.str().c_str();
    if(!std::cout.good())
      throw std::exception("bad iostream state");
  }
  catch(std::exception& ex)
  {
    std::cout.clear();
    std::cout << "\n  " << ex.what();
  }
  std::cout << "\n\n";
}