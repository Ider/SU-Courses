///////////////////////////////////////////////////////////
// MT2Q1alt.h - more direct use of functor than in MT2Q1
//   - Here, instead of graph class, used simpler
//     node class to illustrate idea

#include <vector>

template <typename T> class node;

template <typename T>
struct IFunc
{
  enum OpType { vertexOp, edgeOp };
  typedef void(IFunc<T>::*callback)(typename T t);
  virtual void operator()(T t, OpType ot)=0;
};

template <typename T>
class node
{
public:
  node(size_t number, T t=0) : nodeNum_(number), value_(t), visited_(false), pFunc_(0) {}
  ~node()
  { 
    // Can't delete children unless you are sure they were created on heap
    // for(size_t i=0; i<children_.size(); ++i)
    //   delete children_[i];
  }
  size_t& number() { return nodeNum_; }
  T& value() { return value_; }
  void add(node<T>* pNode) { children_.push_back(pNode); }
  bool& visited() { return visited_; }
  size_t size() { return children_.size(); }
  node<T>* getNextUnmarkedChild()
  {
    for(size_t i=0; i<children_.size(); ++i)
      if(!children_[i]->visited())
        return children_[i];
    return 0;
  }
  void doNodeOp() { if(pFunc_) (*pFunc_)(this, IFunc<node<T>*>::vertexOp); }
  void doEdgeOp() { if(pFunc_) (*pFunc_)(this, IFunc<node<T>*>::edgeOp); }
  void Register(IFunc<node<T>*>* pFunc)
  {
    pFunc_ = pFunc;
  }
private:
  size_t nodeNum_;
  T value_;
  std::vector<node*> children_;
  bool visited_;
  IFunc<node<T>*>* pFunc_;
};

template <typename T>
void DFS(node<T>* pNode, IFunc<node<T>*>& f)
{
  static int lev = 1;
  pNode->visited() = true;
  pNode->doNodeOp();
  for(size_t i=0; i<pNode->size(); ++i)
  {
    node<T>* pChild = pNode->getNextUnmarkedChild();
    if(pChild)
    {
      pChild->doEdgeOp();
      DFS(pChild,f);
    }
  }
  --lev;
}

