///////////////////////////////////////////////////////////
// MT2Q1alt.cpp - more direct use of functor than in MT2Q1

#include "MT2Q1alt.h"
#include <string>
#include <iostream>

typedef std::string stdStr;

class functor : public IFunc<node<stdStr>*>
{
  void operator()(node<stdStr>* pNode, IFunc<node<stdStr>*>::OpType ot)
  {
    if(ot == IFunc<node<stdStr>*>::vertexOp)
      std::cout << "\n  vertexOp: " << pNode->value();
    else
      std::cout << "\n  edgeOp:   " << pNode->value();
  }
};

void main()
{
  functor f;
  node<stdStr> n1(1,"one");   n1.Register(&f);
  node<stdStr> n2(2,"two");   n2.Register(&f);
  node<stdStr> n3(3,"three"); n3.Register(&f);
  node<stdStr> n4(4,"four");  n4.Register(&f);
  node<stdStr> n5(5,"five");  n5.Register(&f);
  node<stdStr> n6(6,"six");   n6.Register(&f);
  node<stdStr> n7(7,"seven"); n7.Register(&f);
  n1.add(&n2);
  n1.add(&n3);
  n3.add(&n4);
  n1.add(&n5);
  n4.add(&n6);
  n6.add(&n7);
  DFS(&n1,f);
  std::cout << "\n\n";
}
