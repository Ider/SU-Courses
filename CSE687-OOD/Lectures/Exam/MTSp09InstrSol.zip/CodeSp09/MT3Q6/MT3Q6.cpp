// MT3Q6.cpp

#include <set>
#include <list>
#include <map>
#include <string>
#include <iostream>

typedef std::set<std::string> paths; 		      // each path has one entry
typedef std::list<paths::iterator> pathRefs;	// list of paths where a file is found
typedef std::string file;				              // a file
typedef std::map< file, pathRefs > fileInfos;	// a collection of directory tree info
                                 							//    with unique file and path names
void main()
{
  paths testPaths;
  testPaths.insert("c:\\temp");
  testPaths.insert("c:\\su\\CSE687\\code\\demos");
  testPaths.insert("c:\\su\\CSE687\\code\\olddemos");
  file testFile = "demo.cpp";
  pathRefs testPathRefs;
  testPathRefs.push_back(testPaths.find("c:\\su\\CSE687\\code\\demos"));
  testPathRefs.push_back(testPaths.find("c:\\su\\CSE687\\code\\olddemos"));
  fileInfos testFileInfos;
  testFileInfos[testFile] = testPathRefs;
  testFile = "temp.txt";
  testPathRefs.clear();
  testPathRefs.push_back(testPaths.find("c:\\temp"));
  testPathRefs.push_back(testPaths.find("c:\\su\\CSE687\\code\\demos"));
  testFileInfos[testFile] = testPathRefs;

  std::map<file,pathRefs>::iterator iter;
  std::list<paths::iterator>::iterator jter;
  for(iter=testFileInfos.begin(); iter!=testFileInfos.end(); ++iter)
  {
    std::cout << "\n  " << iter->first.c_str();
    for(jter=iter->second.begin(); jter!=iter->second.end(); ++jter)
      std::cout << "\n    " << (*jter)->c_str();
  }
  std::cout << "\n\n";
}