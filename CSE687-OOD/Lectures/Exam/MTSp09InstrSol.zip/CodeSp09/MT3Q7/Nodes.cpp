///////////////////////////////////////////////////////////////////////////
// Nodes.cpp - demonstrate how to define a template node class           //
// ver 1.1                                                               //
// Language:    Visual C++, 2008                                         //
// Platform:    Dell Precision T7400, Vista Ultimate, SP1                //
// Application: CSE382 - Algorithms and Data Structures Demo, Fall 2008  //
// Author:      Jim Fawcett, Syracuse University, CST 4-187,             //
//              (315) 443-3948, jfawcett@twcny.rr.com                    //
///////////////////////////////////////////////////////////////////////////

#include "Nodes.h"
using namespace CppNodes;

void walkList(Node<int>* pNode)
{
  std::cout << "  " << pNode->value();
  if(pNode->next() != 0)
    walkList(pNode->next());
}
void main()
{
  std::cout << "\n  Node<T> class demonstration";
  std::cout << "\n =============================\n";

  Node<int> n0(0,4);    std::cout << "\n  constructing node n0";
  Node<int> n1(&n0,3);  std::cout << "\n  constructing node n1";
  Node<int> n2(&n1,2);  std::cout << "\n  constructing node n2";
  Node<int> n3(&n2,1);  std::cout << "\n  constructing node n3";
  Node<int> n4(&n3,0);  std::cout << "\n  constructing node n4\n\n";

  walkList(&n4);
  std::cout << "\n";

  // bypass node 2

  n3.next() = &n1;  std::cout << "\n  by-passing node n2\n\n";
  walkList(&n4);
  std::cout << "\n";

  // If you create nodes on the process heap you should
  // subsequently delete them

  Node<int>* pNode = new Node<int>(0,5);
  std::cout << "\n value of node on heap is: " << pNode->value();
  delete pNode;

  std::cout << "\n\n";

  list<std::string> ls;
  ls.add("exams");
  ls.add("projects");
  ls.add("help sessions");
  ls.add("TA office hours");
  ls.front();

  for(size_t i=0; i<ls.size(); ++i)
  {
    std::cout << ls.value().c_str() << " ";
    ls.next();
  }
  std::cout << "\n\n";
}
