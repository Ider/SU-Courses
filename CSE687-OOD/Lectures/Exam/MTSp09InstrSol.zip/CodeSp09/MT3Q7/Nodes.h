#ifndef Nodes_H
#define Nodes_H
///////////////////////////////////////////////////////////////////////////
// Nodes.h - demonstrate how to define a template node class             //
// ver 1.2                                                               //
// Language:    Visual C++, 2008                                         //
// Platform:    Dell Precision T7400, Vista Ultimate, SP1                //
// Application: CSE382 - Algorithms and Data Structures Demo, Fall 2008  //
// Author:      Jim Fawcett, Syracuse University, CST 4-187,             //
//              (315) 443-3948, jfawcett@twcny.rr.com                    //
///////////////////////////////////////////////////////////////////////////
/*
 * Module Operations:
 * ==================
 * Provides a template Node class that has successor pointer and value
 * members, and value() and next() member functions.
 *
 * Note for CSE687 Spring 2009:
 * You will need to modify this class to use for your parse tree.  Your nodes
 * have to hold an arbitrary finite number of pointers to child nodes.  You
 * probably want to use a std::vector or std::list for that.  In order to easily
 * traverse a tree built out of these modified nodes you will need a predicate 
 * field to mark their visitation status.
 * 
 * Build Process:
 * ==============
 * cl /D:TEST_NODES Nodes.cPP
 * 
 * Maintenance History:
 * ====================
 * ver 1.2 : 22 Jan 09
 * - added comments, above, for CSE687 Project #1
 * ver 1.1 : 02 Sep 08
 * - cosmetic changes to prologue
 * ver 1.0 : 28 Aug 08
 * - first release
 */

#include <iostream>

namespace CppNodes
{
  template <typename T>
  class Node
  {
  public:
    Node(Node<T>* pNode, const T& t=0) : next_(pNode), t_(t) {};
    T& value() { return t_; }
    Node<T>*& next() { return next_; }
    // Compiler generated copy and assignment are shallow.
    // That makes sense for a Node class.
  private:
    Node<T>* next_;
    T t_;
  };

  template <typename T>
  class list
  {
  public:
    list() : pHead(0), pCurrent(0), size_(0) {}
    size_t size() { return size_; }
    void add(const T& t)
    {
      if(size() == 0)
        pHead = pCurrent = new Node<T>(0,t);
      else
        pCurrent = pCurrent->next()= new Node<T>(0,t);
      ++size_;
    }
    Node<T>* next()
    {
      if(pCurrent)
        return (pCurrent = pCurrent->next());
      else
        return pCurrent;
    }
    T& front() 
    {
      pCurrent = pHead;
      return value();
    }
    T front() const 
    {
      pCurrent = pHead;
      return value();
    }
    T& value() { return pCurrent->value(); }
    T value() const { return pCurrent->value(); }
  private:
    Node<T>* pHead;
    Node<T>* pCurrent;
    size_t size_;
  };
}

#endif
