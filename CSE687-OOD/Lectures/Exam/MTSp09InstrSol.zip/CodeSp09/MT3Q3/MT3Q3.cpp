// MT3Q3.cpp

#include <iostream>

class B 
{
public:
  B() { std::cout << "\n  default construction of B"; }
  B(const B& b) { std::cout << "\n  copy construction of B"; }
  virtual ~B() { std::cout << "\n  destroying B"; }
  void say() const { std::cout << "\n  B here"; }
};

class C
{
public:
  C() : val(0)
  { 
    std::cout << "\n  default construction of C"; 
  }
  C(const C& c) : val(c.val)
  {
    std::cout << "\n  copy construction of C";
  }
  ~C() { std::cout << "\n  destroying C"; }
  void say() const 
  { 
    std::cout << "\n  C here"; 
    std::cout << "\n  my value is " << value();
  }
  double& value() { return val; }
  double value() const { return val; }
private:
  double val;
};

class U
{
public:
  U() { std::cout << "\n  default construction of U"; }
  U(const U& u) { std::cout << "\n  copy construction of U"; }
  ~U() { std::cout << "\n  destroying U"; }
  void say() const { std::cout << "\n  U here"; }
};

class D : public B
{
public:
  D() { std::cout << "\n  default construction of D"; }
  D(const D& d) : B(d), c(d.c) 
  { 
    std::cout << "\n  copy construction of D"; 
  };
  D& operator=(const D& d)
  {
    if(&d == this) return *this;
    static_cast<B&>(*this) = d;
    c = d.c;
    return *this;
  }
  ~D() { std::cout << "\n  destroying D"; }
  void say(const U& u) const
  { 
    std::cout << "\n  D here";
    c.say();
    u.say();
  }
  double& value() { return c.value(); }
private:
  C c;
};

class modD : public B
{
public:
  modD() : pC(new C) { std::cout << "\n  default construction of modD"; }
  modD(const modD& d) : B(d), pC(new C(*d.pC)) 
  { 
    std::cout << "\n  copy construction of modD"; 
  };
  modD& operator=(const modD& md)
  {
    if(&md == this) return *this;
    static_cast<B&>(*this) = md;
    if(pC)
      pC = new C(*md.pC);
    else
      pC = 0;
    return *this;
  }
  ~modD() 
  { 
    std::cout << "\n  destroying modD"; 
    delete pC;
  }
  void say(const U& u) const
  { 
    std::cout << "\n  modD here";
    pC->say();
    u.say();
  }
  double& value() { return pC->value(); }
private:
  C* pC;
};

D* f(D d) { return new D(d); }  

void main()
{
  D d;  
  D* pD;
  D t = *(pD =f(d));
  delete pD;
}