// MT4Q4.cpp

#include <string>
#include <iostream>

#define TESTMODULE2

struct ITest 
{
  virtual bool test()=0;
  virtual std::string name() { return typeid(*this).name(); }
  virtual ~ITest() {};
};

class factory
{
public:
  ITest* Create();
};

#ifdef TESTMODULE1

class Module1
{
public:
  void opA(std::string& s) { s = "Lucretia Borge"; }
  std::string opB(const std::string& s)
  {
    if(s == "Arnold") return "terminator";
    if(s == "Wiley") return "cayote";  // note misspelled
    if(s == "Luke") return "Darth";
    return "Don't know";
  }
};

class Module1Test : public ITest
{
public:
  bool test()
  {
    if(mod.opB("Arnold") != "terminator") return false;
    if(mod.opB("Wiley") != "Coyote") return false;  // fails due to spelling error in Module1
    if(mod.opB("Luke") != "Darth") return false;
    std::string s = "ardvark"; mod.opA(s);
    if(s != "Lucretia Borge") return false;
    return true;
  }
private:
  Module1 mod;
};

ITest* factory::Create()
{
  return new Module1Test;
}

#endif

#ifdef TESTMODULE2

class Module2
{
public:
  void func() { std::cout << "\n  running Module2"; }
};

class Module2Test : public ITest
{
public:
  bool test() 
  {
    mod.func();
    // anything module2 does is correct :-)
    return true; 
  }
  Module2 mod;
};

ITest* factory::Create()
{
  return new Module2Test;
}

#endif

#ifdef TESTMODULE3

class Module3
{
public:
  int comp() { throw std::exception("bad test"); }
};

class Module3Test : public ITest
{
public:
  bool test() 
  {
    try
    {
      int z = mod.comp();
      return (z!=0);
    }
    catch (std::exception& ex)
    {
      std::cout << "\n  " << ex.what();
      return false;
    }
  }
  private:
    Module3 mod;
};

ITest* factory::Create()
{
  return new Module3Test;
}

#endif

void main()
{
  std::cout << "\n  Demonstrating ITest interface";
  std::cout << "\n ===============================\n";

  factory f;
  ITest* pTest = f.Create();
  std::cout << "\n  " << pTest->name() << ((pTest->test()) ? " passed" : " failed") << "\n\n";
}