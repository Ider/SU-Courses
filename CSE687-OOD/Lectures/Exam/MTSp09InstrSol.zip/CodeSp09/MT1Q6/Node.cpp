#include "Node.h"
#include <string>
#include <iostream>

typedef std::string stdStr;

template <bool Delete>
class functor : public IFunc<stdStr,Delete>
{
  void operator()(node<stdStr,Delete>* pNode, int level)
  {
    std::cout << "\n";
    for(int i=0; i<level; ++i)
      std::cout << "  ";
    std::cout << pNode->value();
  }
};

//template <bool Delete>
//class functorWithCallbacks : public IFunc<stdStr,Delete>
//{
//  void operator()(node<stdStr,Delete>* pNode, int level)
//  {
//    std::cout << "\n";
//    for(int i=0; i<level; ++i)
//      std::cout << "  ";
//    std::cout << pNode->value();
//  }
//};

void main()
{
  node<stdStr,false> n1(1,"one");
  node<stdStr,false> n2(2,"two");
  node<stdStr,false> n3(3,"three");
  node<stdStr,false> n4(4,"four");
  node<stdStr,false> n5(5,"five");
  node<stdStr,false> n6(6,"six");
  node<stdStr,false> n7(7,"seven");
  n1.add(&n2);
  n1.add(&n3);
  n3.add(&n4);
  n1.add(&n5);
  n4.add(&n6);
  n6.add(&n7);
  functor<false> f;
  DFS(&n1,f);
  std::cout << "\n\n";

  node<stdStr,true>* pNode1 = new node<stdStr,true>(1,"one");
  node<stdStr,true>* pNode2 = new node<stdStr,true>(1,"two");
  node<stdStr,true>* pNode3 = new node<stdStr,true>(1,"three");
  node<stdStr,true>* pNode4 = new node<stdStr,true>(1,"four");
  node<stdStr,true>* pNode5 = new node<stdStr,true>(1,"five");
  node<stdStr,true>* pNode6 = new node<stdStr,true>(1,"six");
  node<stdStr,true>* pNode7 = new node<stdStr,true>(1,"seven");
  pNode1->add(pNode2);
  pNode1->add(pNode3);
  pNode3->add(pNode4);
  pNode1->add(pNode5);
  pNode4->add(pNode6);
  pNode6->add(pNode7);
  functor<true> ft;
  DFS(pNode1,ft);
  std::cout << "\n\n";
}
