#ifndef HELPNODE_H
#define HELPNODE_H
/////////////////////////////////////////////////////////////////////////
// MT4Q6.h - demonstrate how to build an m-ary node class

#include <vector>

namespace VSHelpS09
{
  class Node
  {
  public:
    Node(const std::string& value="");
    void add(Node* pNode);
    size_t size();
    Node* nextUnmarkedChild();
    bool removeChild(Node* pChild);
    std::string& value();
    bool& isMarked();
  private:
    std::vector<Node*> nodePtrs;
    std::vector< std::pair<std::string, std::string> > attribs;
    bool visited;
    std::string value_;
  };
  //-- create and initialize node

  inline Node::Node(const std::string& value) : visited(false), value_(value) {}

  //-- bind child node to parent

  inline void Node::add(Node* pNode)
  {
    nodePtrs.push_back(pNode);
  }
  //-- return number of children

  inline size_t Node::size() { return nodePtrs.size(); }
  
  //-- return node text (will be tag)

  inline std::string& Node::value() { return value_; }

  //-- return marked predicate

  inline bool& Node::isMarked() { return visited; }
}

#endif
