// MT4Q6.cpp

/////////////////////////////////////////////////////////////////////////
// MT4Q6.cpp

#include <iostream>
#include "MT4Q6.h"

using namespace VSHelpS09;

//-- return next unmarked child node

Node* Node::nextUnmarkedChild()
{
  for(size_t i=0; i<size(); ++i)
  {
    if(!nodePtrs[i]->isMarked())
    {
      return nodePtrs[i];
    }
  }
  return 0;
}
//-- attempt to remove child

bool Node::removeChild(Node* pChild)
{
  std::vector<Node*>::iterator iter;
  for(iter=nodePtrs.begin(); iter!=nodePtrs.end(); ++iter)
  {
    if(*iter == pChild)
    {
      nodePtrs.erase(iter);
      return true;
    }
  }
  return false;
}
//-- bind name and value to attribute collection - TBD
//-- return attribute collection - TBD

//----< test stub >------------------------------------------------------

//-- visit each node in tree using depth first search

void walk(Node* pNode)
{
  std::cout << "\n  " << (pNode->value()).c_str();
  Node* pTemp;
  for(size_t i=0; i<pNode->size(); ++i)
  {
    pTemp = pNode->nextUnmarkedChild();
    if(pTemp != 0)
    {
      pTemp->isMarked() = true;
      walk(pTemp);
    }
  }
}
void main()
{
  std::cout << "\n  Testing Node class";
  std::cout << "\n ====================\n";

  //-- create nodes

  Node root("root");
  Node child1("child1");
  Node child2("child2");
  Node grandchild11("grandchild11");
  
  //-- connect "tree"

  child1.add(&grandchild11);
  root.add(&child1);
  root.add(&child2);

  std::cout << "\n  walking connected nodes";
  walk(&root);

  std::cout << "\n\n  adding grandchildren";

  //-- unmark to prepare for next traversal

  root.isMarked() = false;
  child1.isMarked() = false;
  child2.isMarked() = false;
  grandchild11.isMarked() = false;
  
  //-- create more nodes

  Node grandchild21("grandchild21");
  Node grandchild22("grandchild22");
  
  //-- connect into "tree"

  child2.add(&grandchild21);
  child2.add(&grandchild22);

  std::cout << "\n\n  walking connected nodes";
  walk(&root);

  std::cout << "\n\n  removing grandchild";

  //-- unmark to prepare for next traversal

  root.isMarked() = false;
  child1.isMarked() = false;
  child2.isMarked() = false;
  grandchild11.isMarked() = false;
  grandchild21.isMarked() = false;
  grandchild22.isMarked() = false;
  child2.removeChild(&grandchild21);

  std::cout << "\n\n  walking connected nodes";
  walk(&root);

  std::cout << "\n\n";
}
