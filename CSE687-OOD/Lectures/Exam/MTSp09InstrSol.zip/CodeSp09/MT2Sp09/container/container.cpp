// container.cpp

#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <string>

template <typename C>
std::string show(const C& con)
{
  std::ostringstream out;
  C::const_iterator iter;
  for(iter=con.begin(); iter!=con.end(); ++iter)
    out << "\n  " << *iter;
  out << "\n\n";
  return out.str();
}

void main()
{
  std::string myFriends[] = {
    "Terminator",
    "Jack The Ripper",
    "Lucretia Borgia",
    "Attila the Hun",
    "Genghis Khan"
  };

  std::list<std::string> friends(myFriends, myFriends+5);
  
  try 
  {
    std::ostringstream outss;
    outss << show(friends);
    if(!outss.good())
      throw std::exception("bad ostringstream state");
    std::ofstream outfs("outfile.txt",std::ios::out);
    outfs << outss.rdbuf();
    if(!outfs.good())
      throw std::exception("bad ofstream state");
    outfs.close();
    outss.seekp(std::ios::beg);
    std::cout << outss.rdbuf();
    if(!std::cout.good())
      throw std::exception("bad iostream state");
  }
  catch(std::exception& ex)
  {
    std::cout.clear();
    std::cout << "\n  " << ex.what();
  }
  std::cout << "\n\n";
}