// MT2Q2alt.cpp

///////////////////////////////////////////////////////////
// enclosed counted as complete solution

template <typename T>
class array
{
public:
  array(size_t n=5);
  array(const array& arr);
  ~array();
  array& operator=(const array& arr);
  T& operator[](size_t n);
  T operator[](size_t n) const;
  void append(const T& t);
  size_t size();
private:
  void resize(size_t newCapacity);
  T* pT_;
  size_t size_, capacity_;
};

template <typename T>
T& array<T>::operator[](size_t n)
{
  if(n<0 || size_ <= n)
    throw std::exception("index outside bounds of array");
  return pT_[n];
}

template <typename T>
T array<T>::operator[](size_t n) const
{
  if(n<0 || size_ <= n)
    throw std::exception("index outside bounds of array");
  return pT_[n];
}

template <typename T>
void array<T>::append(const T& t)
{
  if(capacity_ == size_)
    resize(2*size_);
  pT_[size_++] = t;
}

template <typename T>
void array<T>::resize(size_t newCapacity)
{
  if(newCapacity <= capacity_)
    throw std::exception("new capacity must be larger than old");
  else
    capacity_ = newCapacity;
  T* temp = new T[capacity_];
  for(size_t i=0; i<size_; ++i)
    temp[i] = pT_[i];
  for(size_t i=size_; i<capacity_; ++i)
    temp[i] = 0;
  delete [] pT_;
  pT_ = temp;
}
//
///////////////////////////////////////////////////////////

template <typename T>
array<T>::array(size_t n=5) : pT_(new T[n]), size_(n), capacity_(n)
{
  for(size_t i=0; i<n; ++i)
    pT_[i] = 0;
}

template <typename T>
array<T>::array(const array<T>& arr) : size_(arr.size_), capacity_(arr.capacity_)
{
  pT_ = new T[arr.capacity_];
  for(size_t i=0; i<arr.capacity_; ++i)
    pT_[i] = arr.pT_[i];
}

template <typename T>
array<T>::~array(){ delete [] pT_; }

template <typename T>
array<T>& array<T>::operator=(const array<T>& arr)
{
  if(this == &arr) return *this;
  delete pT_;
  pT_ = new T[arr.size_];
  for(int i=0; i<arr.capacity_; ++i)
    pT_[i] = arr.pT_[i];
}

template <typename T>
size_t array<T>::size() { return size_; }

#include <iostream>

template <typename T>
void show(array<T>& arr)
{
  std::cout << "\n  ";
  for(size_t i=0; i<arr.size(); ++i)
    std::cout << arr[i] << " ";
  std::cout << "\n";
}

void main()
{
  array<int> arr(3);
  try
  {
    arr[0] = 0;
    arr[1] = 1;
    arr[2] = 2;
    arr.append(3);
    arr.append(4);
    arr.append(5);
    arr.append(6);

    // will throw exception - outside bounds of array
    // arr[7] = 7;

    show(arr);
    array<int> copy = arr;
    show(copy);
  }
  catch(std::exception& ex)
  {
    std::cout << "\n  " << ex.what();
  }
}