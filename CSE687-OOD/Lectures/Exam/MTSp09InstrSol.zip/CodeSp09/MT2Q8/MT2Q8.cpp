// MT2Q8.cpp

#include <iostream>
#include <list>
#include <vector>

template <typename C>
void show(const C& c)
{
  std::cout << "\n  ";
  C::const_iterator iter;
  for(iter=c.begin(); iter!=c.end(); ++iter)
    std::cout << (*iter).c_str() << " ";
}

template <typename T>
struct IFunctor
{
  virtual bool operator()(T& t)=0;
  virtual ~IFunctor() {}
};

template <typename T>
class SampleFunctor : public IFunctor<T>
{
public:
  SampleFunctor(char chr='A') : ch(chr) {}
  bool operator()(T& t)
  {
    return (t[0] == ch) ? true : false;
  }
private:
  char ch;
};

template <typename U, typename V>
void copy_ifeach(U& u, V& v, IFunctor<typename U::value_type>& f)
{
  U::iterator iter;
  for(iter=u.begin(); iter!=u.end(); ++iter)
    if(f(*iter))
      v.push_back(*iter);
}

void main()
{
  std::string names[] = { "Arjun", "Bill", "Priya", "Aaron", "John", "Yu" };
  std::list<std::string> ls(&names[0],&names[6]);
  show(ls);
  std::vector<std::string> vs;
  copy_ifeach(ls,vs,SampleFunctor<std::string>());
  show(vs);
  copy_ifeach(ls,vs,SampleFunctor<std::string>('Y'));
  show(vs);
  std::cout << "\n\n";
}