// MT2Q5.cpp

#include <iostream>
#include "Navigator.h"
#include "FileSystem.h"

using namespace WinTools_Extracts;

class DirNav : public IDirNav
{
public:
  void file(const std::string& filespec) 
  {
    FileHandler fn;
    std::string filename = fn.getFileName(filespec);
    std::cout << "\n    " << filename.c_str(); 
  }
  void directory(const std::string& dirspec) 
  { 
    std::cout << "\n  " << dirspec.c_str(); 
  }
};

void main()
{
  Navigator nav("*.*");
  nav.reg(new DirNav);
  nav.go("c:\\temp");
  std::cout << "\n\n  That's all folks!\n\n";
}

