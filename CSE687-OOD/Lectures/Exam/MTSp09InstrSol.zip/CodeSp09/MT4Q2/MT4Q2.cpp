// MT4Q2.cpp

#include <iostream>

template <typename T>
class clonerBase
{
public:
  clonerBase() {}
  clonerBase(const clonerBase<T>& cb) 
  { 
    std::cout << "\n  making copy of clonerBase<T>"; 
  }
  static clonerBase<T>* sclone() { return new T; }  // returns new default instance
  static clonerBase<T>* sclone(T* pT) { return new T(*pT); }  // returns copy
  clonerBase<T>* clone(T* pT) { return new T(*pT); } // returns copy
  clonerBase<T>* clone() // returns copy of derived using base pointer
  { 
    T* temp = dynamic_cast<T*>(this);
    if(temp)
      return new T(*temp);
    else
      return 0;
  }
  virtual void op()=0 { std::cout << "\n  Hi from " << typeid(*this).name(); }
  // virtual void op()=0 { std::cout << "\n  Hi from " << typeid(T).name(); }
  // this works too
  virtual ~clonerBase<T>() {};
};

class clonerD1 : public clonerBase<clonerD1>
{
public:
  void op() { std::cout << "\n  Hi from clonerD1"; }
};

class clonerD2 : public clonerBase<clonerD2>
{
public:
  void op() { std::cout << "\n  Hi from clonerD2"; }
};

class clonerD3 : public clonerBase<clonerD3> 
{
public:
  void op() { clonerBase<clonerD3>::op(); }
};

void main()
{
  // These clones simply return a new object of derived type

  clonerBase<clonerD1>* pD1 = clonerBase<clonerD1>::sclone();
  pD1->op();
  delete pD1;
  clonerBase<clonerD2>* pD2 = clonerBase<clonerD2>::sclone();
  pD2->op();
  delete pD2;

  // These copy generators will not accept a base pointer,
  // as that would require an implicit downcast which the
  // compiler is unwilling to do.  Need dynamic_cast, 
  // illustrated after these two

  clonerD2 cD2;
  clonerBase<clonerD2>* pD2a = clonerBase<clonerD2>::sclone(&cD2);
  pD2a->op();
  clonerBase<clonerD2>* pD2b = pD2a->clone(&cD2);
  pD2b->op();

  // We can return copy of derived without passing a specific argument.
  // Type of copy is dynamic type of pointer used to invoke it, e.g.
  // clonerD2, below.

  clonerBase<clonerD2>* pV = pD2->clone();
  pV->op();
  delete pD2a;

  // This shows that op() can be defined in base class too

  clonerBase<clonerD3>* pD3 = clonerBase<clonerD3>::sclone();
  pD3->op();
  delete pD3;
  std::cout << "\n\n";
}
