///////////////////////////////////////////////////////////
// MT2Q1.cpp

#include "MT2Q1.h"
#include <string>
#include <iostream>

typedef std::string stdStr;

class functor : public IFunc<stdStr>
{
  virtual void nodeOp(node<stdStr>* pNode)
  {
    std::cout << "\n  node# " << pNode->number();
  }
  virtual void edgeOp(node<stdStr>* pNode)
  {
    std::cout << "\n  child node# " << pNode->number();
  }
  void operator()(node<stdStr>* pNode, int level)
  {
    std::cout << "\n";
    for(int i=0; i<level; ++i)
      std::cout << "  ";
    std::cout << pNode->value();
  }
};

void main()
{
  functor f;
  node<stdStr> n1(1,"one");   n1.Register(&f);
  node<stdStr> n2(2,"two");   n2.Register(&f);
  node<stdStr> n3(3,"three"); n3.Register(&f);
  node<stdStr> n4(4,"four");  n4.Register(&f);
  node<stdStr> n5(5,"five");  n5.Register(&f);
  node<stdStr> n6(6,"six");   n6.Register(&f);
  node<stdStr> n7(7,"seven"); n7.Register(&f);
  n1.add(&n2);
  n1.add(&n3);
  n3.add(&n4);
  n1.add(&n5);
  n4.add(&n6);
  n6.add(&n7);
  DFS(&n1,f);
  std::cout << "\n\n";
}
