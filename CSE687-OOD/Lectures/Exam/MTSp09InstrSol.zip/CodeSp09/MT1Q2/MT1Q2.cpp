// MT1Q2.cpp

#include <iostream>
#include <sstream>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <string>

template <typename C>
std::string show(const C& con)
{
  std::ostringstream out;
  C::const_iterator iter;
  std::cout << "\n  ";
  for(iter=con.begin(); iter!=con.end(); ++iter)
  {
    out << *iter << " ";
    if(typeid(*iter) == typeid(std::string))
      out << "\n  ";
  }
  return out.str();
}

void main()
{
  std::string myFriends[] = {
    "Terminator",
    "Jack The Ripper",
    "Lucretia Borgia",
    "Attila the Hun",
    "Genghis Khan"
  };

  int myNumbers[] = { 0, 1, 2, 3, 2, 1, 0 };

  std::vector<std::string> vecfriends(myFriends, myFriends+5);
  std::cout << show(vecfriends) << "\n";
  std::list<std::string> lstfriends(myFriends, myFriends+5);
  std::cout << show(lstfriends) << "\n";
  std::set<std::string> setfriends(myFriends, myFriends+5);
  std::cout << show(setfriends) << "\n";

  std::list<int> lstNumbers(myNumbers, myNumbers+7);
  std::cout << show(lstNumbers) << "\n";

  std::cout << "\n";
}